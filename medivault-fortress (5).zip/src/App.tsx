import React, { useState, useEffect, createContext, useContext, useRef } from 'react';
import confetti from 'canvas-confetti';
import { 
  LayoutDashboard, Scan, MessageSquare, History, Settings, TrendingUp, Pill, 
  AlertCircle, Plus, Copy, Download, Share2, FileText, Search, LogOut, Shield,
  Lock, Fingerprint, Camera, AlertTriangle, ChevronRight, ArrowRight, X, Menu, Mic
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { jsPDF } from "jspdf";
import * as XLSX from "xlsx";
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';

// --- UTILS & SERVICES ---

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

const OCR_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    documentType: { type: Type.STRING },
    fields: {
      type: Type.OBJECT,
      properties: {
        hospitalName: { type: Type.STRING },
        date: { type: Type.STRING },
        totalAmount: { type: Type.NUMBER },
        taxAmount: { type: Type.NUMBER },
        discountAmount: { type: Type.NUMBER },
        items: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: { 
              name: { type: Type.STRING }, 
              qty: { type: Type.NUMBER },
              mrp: { type: Type.NUMBER },
              rate: { type: Type.NUMBER },
              discount: { type: Type.NUMBER },
              total: { type: Type.NUMBER }
            }
          }
        },
        allLines: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              originalText: { type: Type.STRING },
              interpretedCategory: { type: Type.STRING }
            }
          },
          description: "Every single line of text found on the bill, for complete accuracy."
        }
      }
    },
    fullRawText: { type: Type.STRING, description: "Complete OCR text from the image without any filtering" },
    summaryHindi: { type: Type.STRING, description: "Detailed summary of the bill in Hindi including key items and total" }
  },
  required: ["documentType", "fields", "summaryHindi", "fullRawText"]
};

async function hashPassword(password: string): Promise<string> {
  const msgUint8 = new TextEncoder().encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// --- THEMES & CHROMATIC PALETTES ---

export const GRAPHIC_THEMES: Record<string, {
  name: string;
  primary: string;
  secondary: string;
  accent: string;
  gradient: string;
  buttonGlow: string;
  cardBorder: string;
  badge: string;
  ambient: string;
  glassGlow: string;
  bgApp: string;
  charts: {
    start: string;
    end: string;
  };
  blob1: string;
  blob2: string;
  blob3: string;
  blob4: string;
  heroGradient: string;
}> = {
  nebula: {
    name: "Nebula Cosmic",
    primary: "text-fuchsia-400 font-bold",
    secondary: "text-indigo-400",
    accent: "text-pink-400",
    gradient: "from-fuchsia-500 via-purple-600 to-indigo-500",
    buttonGlow: "hover:shadow-[0_0_25px_rgba(168,85,247,0.45)]",
    cardBorder: "hover:border-fuchsia-500/30",
    badge: "bg-fuchsia-500/10 text-fuchsia-300 border-fuchsia-500/20",
    ambient: "from-transparent via-fuchsia-500/30 via-cyan-500/30 to-transparent",
    glassGlow: "glass-border-neon-purple",
    bgApp: "bg-[#03030d]",
    charts: { start: "#d946ef", end: "#6366f1" },
    blob1: "from-fuchsia-600/20 via-purple-600/25 to-indigo-600/15",
    blob2: "from-pink-500/20 via-violet-600/20 to-indigo-700/15",
    blob3: "from-purple-500/15 via-rose-500/15 to-violet-800/10",
    blob4: "from-indigo-500/15 via-fuchsia-500/15 to-purple-800/10",
    heroGradient: "from-indigo-900/60 via-purple-900/40 to-pink-900/50"
  },
  aurora: {
    name: "Liquid Aurora",
    primary: "text-cyan-400 font-bold",
    secondary: "text-emerald-400",
    accent: "text-teal-400",
    gradient: "from-cyan-500 via-emerald-550 to-teal-500",
    buttonGlow: "hover:shadow-[0_0_25px_rgba(20,184,166,0.45)]",
    cardBorder: "hover:border-cyan-500/30",
    badge: "bg-cyan-500/10 text-cyan-300 border-cyan-500/20",
    ambient: "from-transparent via-cyan-500/30 via-emerald-500/30 to-transparent",
    glassGlow: "glass-border-neon-teal",
    bgApp: "bg-[#020506]",
    charts: { start: "#06b6d2", end: "#10b981" },
    blob1: "from-teal-500/20 via-emerald-600/25 to-cyan-600/15",
    blob2: "from-cyan-500/20 via-blue-600/20 to-teal-700/15",
    blob3: "from-emerald-500/15 via-cyan-500/15 to-blue-800/10",
    blob4: "from-blue-500/15 via-teal-500/15 to-emerald-800/10",
    heroGradient: "from-cyan-900/60 via-emerald-900/40 to-teal-900/50"
  },
  sunset: {
    name: "Cyber Sunset",
    primary: "text-amber-400 font-bold",
    secondary: "text-rose-450",
    accent: "text-orange-400",
    gradient: "from-amber-500 via-orange-500 to-rose-500",
    buttonGlow: "hover:shadow-[0_0_25px_rgba(244,63,94,0.45)]",
    cardBorder: "hover:border-amber-500/30",
    badge: "bg-amber-500/10 text-amber-300 border-amber-500/20",
    ambient: "from-transparent via-amber-500/30 via-rose-500/30 to-transparent",
    glassGlow: "glass-border-neon-purple",
    bgApp: "bg-[#080203]",
    charts: { start: "#f59e0b", end: "#f43f5e" },
    blob1: "from-amber-600/20 via-orange-600/25 to-rose-600/15",
    blob2: "from-pink-500/20 via-red-500/20 to-amber-700/15",
    blob3: "from-rose-500/15 via-amber-550/15 to-purple-800/10",
    blob4: "from-orange-500/15 via-rose-500/15 to-amber-850/10",
    heroGradient: "from-amber-900/60 via-orange-900/40 to-rose-900/50"
  },
  royal: {
    name: "Ultraviolet orchid",
    primary: "text-violet-400 font-bold",
    secondary: "text-indigo-400",
    accent: "text-fuchsia-400",
    gradient: "from-indigo-600 via-violet-600 to-pink-500",
    buttonGlow: "hover:shadow-[0_0_25px_rgba(124,58,237,0.45)]",
    cardBorder: "hover:border-violet-500/30",
    badge: "bg-violet-500/10 text-violet-300 border-violet-500/20",
    ambient: "from-transparent via-indigo-500/30 via-pink-500/30 to-transparent",
    glassGlow: "glass-border-neon-purple",
    bgApp: "bg-[#04020b]",
    charts: { start: "#6366f1", end: "#ec4899" },
    blob1: "from-indigo-600/20 via-violet-600/25 to-fuchsia-600/15",
    blob2: "from-violet-500/20 via-purple-600/20 to-pink-700/15",
    blob3: "from-indigo-500/15 via-pink-500/15 to-violet-800/10",
    blob4: "from-purple-500/15 via-indigo-500/15 to-fuchsia-800/10",
    heroGradient: "from-indigo-900/60 via-violet-900/40 to-fuchsia-900/50"
  }
};

// --- AUTH CONTEXT ---

const AuthContext = createContext<any>(undefined);

function AuthProvider({ children }: { children: React.ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLocked, setIsLocked] = useState(true);
  const [isSetup, setIsSetup] = useState(!!localStorage.getItem('mv_pass_hash'));
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [liquidTheme, setLiquidTheme] = useState<string>(localStorage.getItem('mv_liquid_theme') || 'nebula');

  const updateTheme = (theme: string) => {
    localStorage.setItem('mv_liquid_theme', theme);
    setLiquidTheme(theme);
  };

  const login = async (password: string) => {
    const storedHash = localStorage.getItem('mv_pass_hash');
    const inputHash = await hashPassword(password);
    if (inputHash === storedHash) {
      setIsAuthenticated(true);
      setIsLocked(false);
      setFailedAttempts(0);
      return true;
    }
    setFailedAttempts(prev => prev + 1);
    return false;
  };

  const setup = async (password: string, question: string, answer: string) => {
    localStorage.setItem('mv_pass_hash', await hashPassword(password));
    localStorage.setItem('mv_quest', question);
    localStorage.setItem('mv_ans_hash', await hashPassword(answer.toLowerCase()));
    setIsSetup(true);
    setIsAuthenticated(true);
    setIsLocked(false);
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, isLocked, isSetup, login, setup, lock: () => setIsLocked(true), failedAttempts, liquidTheme, updateTheme }}>
      {children}
    </AuthContext.Provider>
  );
}

// --- VISUAL ELEMENTS (GLASSMORPHISM & LIQUIDISM) ---

function LiquidBackground() {
  const { liquidTheme } = useContext(AuthContext);
  const activeParams = GRAPHIC_THEMES[liquidTheme] || GRAPHIC_THEMES.nebula;

  const [mousePos, setMousePos] = useState({ x: -200, y: -200 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-0 transition-colors duration-1000" style={{ backgroundColor: activeParams.bgApp === 'bg-[#03030d]' ? '#03030d' : activeParams.bgApp === 'bg-[#020506]' ? '#020506' : activeParams.bgApp === 'bg-[#080203]' ? '#080203' : '#04020b' }}>
      {/* Liquid Blob 1 */}
      <motion.div
        animate={{
          x: [0, 80, -60, 0],
          y: [0, -100, 110, 0],
          scale: [1, 1.2, 0.85, 1],
          rotate: [0, 90, 180, 360],
          borderRadius: [
            "42% 58% 70% 30% / 45% 45% 55% 55%",
            "70% 30% 52% 48% / 60% 40% 60% 40%",
            "52% 48% 70% 30% / 40% 60% 40% 60%",
            "42% 58% 70% 30% / 45% 45% 55% 55%"
          ]
        }}
        transition={{
          duration: 22,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className={`absolute top-[-10%] left-[-15%] w-[80vw] h-[80vw] bg-gradient-to-tr ${activeParams.blob1} blur-[100px] transition-all duration-1000`}
      />
      
      {/* Liquid Blob 2 */}
      <motion.div
        animate={{
          x: [0, -100, 70, 0],
          y: [0, 80, -90, 0],
          scale: [1, 0.8, 1.15, 1],
          rotate: [360, 270, 90, 0],
          borderRadius: [
            "50% 50% 30% 70% / 50% 60% 40% 60%",
            "30% 70% 70% 30% / 60% 30% 70% 40%",
            "60% 40% 55% 45% / 45% 55% 45% 55%",
            "50% 50% 30% 70% / 50% 60% 40% 60%"
          ]
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className={`absolute bottom-[-15%] right-[-15%] w-[85vw] h-[85vw] bg-gradient-to-br ${activeParams.blob2} blur-[110px] transition-all duration-1000`}
      />

      {/* Liquid Blob 3 */}
      <motion.div
        animate={{
          x: [0, 50, -60, 0],
          y: [0, 110, -90, 0],
          scale: [0.95, 1.15, 0.8, 0.95],
          rotate: [0, -180, 180, 360],
          borderRadius: [
            "65% 35% 65% 35% / 40% 60% 40% 60%",
            "35% 65% 35% 65% / 60% 40% 60% 40%",
            "50% 50% 40% 60% / 40% 50% 50% 60%",
            "65% 35% 65% 35% / 40% 60% 40% 60%"
          ]
        }}
        transition={{
          duration: 16,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className={`absolute top-[25%] left-[20%] w-[60vw] h-[60vw] bg-gradient-to-r ${activeParams.blob3} blur-[120px] transition-all duration-1000`}
      />

      {/* Liquid Blob 4 */}
      <motion.div
        animate={{
          x: [0, -70, 70, 0],
          y: [0, -60, 80, 0],
          scale: [0.8, 1.1, 0.9, 0.8],
          rotate: [180, 360, 0, 180],
          borderRadius: [
            "40% 60% 50% 50% / 50% 40% 60% 50%",
            "60% 40% 60% 40% / 40% 60% 40% 60%",
            "50% 50% 40% 60% / 60% 40% 50% 50%",
            "40% 60% 50% 50% / 50% 40% 60% 50%"
          ]
        }}
        transition={{
          duration: 24,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className={`absolute bottom-[30%] left-[-10%] w-[55vw] h-[55vw] bg-gradient-to-tr ${activeParams.blob4} blur-[100px] transition-all duration-1000`}
      />

      {/* Mouse Follow Glow - The liquid trail spotlight effect */}
      <motion.div
        animate={{
          x: mousePos.x - 120,
          y: mousePos.y - 120,
        }}
        transition={{ type: "smooth", velocity: 0.8, drag: true }}
        className={`absolute w-[240px] h-[240px] rounded-full bg-gradient-to-tr ${activeParams.blob1} blur-[85px] pointer-events-none z-[1] opacity-75`}
        style={{ left: 0, top: 0 }}
      />
      
      {/* Frosted Layer and subtle ambient glaze */}
      <div className="absolute inset-0 bg-[#030206]/75 backdrop-blur-[14px] z-[1]" />
    </div>
  );
}

function FloatingBubbles() {
  const bubbles = Array.from({ length: 8 }).map((_, i) => ({
    id: i,
    size: Math.random() * 55 + 25,
    left: `${Math.random() * 100}%`,
    delay: Math.random() * 4,
    duration: Math.random() * 14 + 14,
    opacity: Math.random() * 0.14 + 0.05
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-[1] opacity-75">
      {bubbles.map(b => (
        <motion.div
          key={b.id}
          initial={{ y: "110%", x: 0 }}
          animate={{
            y: "-10%",
            x: [0, 40, -40, 0],
            borderRadius: [
              "50% 50% 50% 50%",
              "44% 56% 62% 38% / 42% 48% 52% 58%",
              "56% 44% 38% 62% / 58% 52% 48% 42%",
              "50% 50% 50% 50%"
            ]
          }}
          transition={{
            y: { duration: b.duration, repeat: Infinity, ease: "linear", delay: b.delay },
            x: { duration: b.duration / 2, repeat: Infinity, ease: "easeInOut" },
            borderRadius: { duration: 7, repeat: Infinity, ease: "easeInOut" }
          }}
          className="absolute border border-white/10 shadow-[inset_0_4px_16px_rgba(255,255,255,0.08),_0_12px_36px_rgba(0,0,0,0.2)]"
          style={{
            left: b.left,
            width: b.size,
            height: b.size,
            backgroundColor: 'rgba(255, 255, 255, 0.05)',
            opacity: b.opacity,
          }}
        />
      ))}
    </div>
  );
}

// Custom simple toast indicator instead of blocking alert
function Toast({ message, type, onClose }: { message: string, type: 'success' | 'error' | 'info', onClose: () => void }) {
  useEffect(() => {
    const t = setTimeout(onClose, 4000);
    return () => clearTimeout(t);
  }, [onClose]);

  const colors = {
    success: 'from-emerald-500/25 to-teal-500/25 border-emerald-500/35 text-emerald-200',
    error: 'from-rose-500/25 to-pink-500/25 border-rose-500/35 text-rose-200',
    info: 'from-cyan-500/25 to-blue-500/25 border-cyan-500/35 text-cyan-200'
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 50, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 20, scale: 0.95 }}
      className={`fixed bottom-28 left-6 right-6 md:left-auto md:right-6 md:w-96 backdrop-blur-3xl bg-gradient-to-r ${colors[type]} border p-4 rounded-2xl flex items-center justify-between z-[999] shadow-[0_12px_32px_rgba(0,0,0,0.4)]`}
    >
      <div className="flex items-center gap-3">
        <AlertCircle className="w-5 h-5 flex-shrink-0" />
        <p className="text-xs font-semibold uppercase tracking-wider">{message}</p>
      </div>
      <button onClick={onClose} className="text-white/40 hover:text-white p-1">
        <X className="w-4 h-4" />
      </button>
    </motion.div>
  );
}

// --- COMPONENTS ---

function LockScreen() {
  const { login, isSetup, setup, failedAttempts, liquidTheme } = useContext(AuthContext);
  const [password, setPassword] = useState('');
  const [setupData, setSetupData] = useState({ pass: '', quest: '', ans: '' });
  const [alertMsg, setAlertMsg] = useState<{ msg: string; type: 'success' | 'error' | 'info' } | null>(null);

  const theme = GRAPHIC_THEMES[liquidTheme] || GRAPHIC_THEMES.nebula;

  const displayToast = (msg: string, type: 'success' | 'error' | 'info' = 'info') => {
    setAlertMsg({ msg, type });
  };

  const handleSetupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!setupData.pass || !setupData.quest || !setupData.ans) {
      displayToast("Please fill all configuration fields", "error");
      return;
    }
    await setup(setupData.pass, setupData.quest, setupData.ans);
    displayToast("MediVault initialization complete!", "success");
  };

  const handleUnlockSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const success = await login(password);
    if (!success) {
      displayToast("Master Key Rejected", "error");
    }
  };

  return (
    <div className="relative min-h-screen text-white flex items-center justify-center p-6 font-sans overflow-hidden safe-area-inset transition-colors duration-1000">
      <LiquidBackground />
      <FloatingBubbles />

      <motion.div 
        id="lock_screen_container"
        initial={{ opacity: 0, y: 40 }} 
        animate={{ opacity: 1, y: 0 }} 
        transition={{ duration: 0.8, type: "spring", bounce: 0.25 }}
        className="relative w-full max-w-md z-10 glass-panel satin-sheen rounded-[2.5rem] p-8 md:p-10 shadow-[0_32px_64px_rgba(0,0,0,0.65)] overflow-hidden transition-all duration-500"
      >
        <div className={`absolute top-0 inset-x-0 h-[1.8px] bg-gradient-to-r ${theme.ambient}`} />
        <div className="absolute -top-24 -left-20 w-48 h-48 bg-white/[0.02] rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-20 w-48 h-48 bg-white/[0.02] rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col items-center mb-10 relative">
          <motion.div 
            id="holographic_shield_logo"
            whileHover={{ scale: 1.05 }}
            animate={{ 
              borderRadius: ["25% 75% 70% 30% / 30% 30% 70% 70%", "50% 50% 50% 50%", "75% 25% 30% 70% / 50% 50% 50% 50%", "25% 75% 70% 30% / 30% 30% 70% 70%"],
              backgroundColor: ["rgba(255, 255, 255, 0.03)", "rgba(255, 255, 255, 0.05)", "rgba(255, 255, 255, 0.02)", "rgba(255, 255, 255, 0.03)"],
            }}
            transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
            className={`w-24 h-24 flex items-center justify-center mb-6 border border-white/10 shadow-[0_12px_36px_rgba(255,255,255,0.04)] relative cursor-pointer ${theme.cardBorder}`}
          >
            <Shield className={`w-11 h-11 ${theme.secondary} transition-colors duration-1000`} />
          </motion.div>
          <h1 className="text-3xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-slate-200">
            MEDIVALT <span className={`bg-clip-text text-transparent bg-gradient-to-r ${theme.gradient} transition-all duration-1000`}>FORTRESS</span>
          </h1>
          <p className="text-white/35 text-[9px] uppercase tracking-[0.42em] mt-3 font-extrabold">Liquid Crypto Vault</p>
        </div>

        {!isSetup ? (
          <form onSubmit={handleSetupSubmit} className="space-y-5">
            <div className="relative group">
              <input 
                type="password" 
                placeholder="Set Master Password" 
                required 
                className="w-full glass-input rounded-2xl px-6 py-4 outline-none transition-all placeholder:text-white/20 text-white font-semibold" 
                onChange={e => setSetupData({...setupData, pass: e.target.value})} 
              />
              <Lock className="absolute right-5 top-1/2 -translate-y-1/2 w-5 h-5 text-white/20 group-focus-within:text-white/60 transition-colors" />
            </div>
            <div className="relative group">
              <input 
                type="text" 
                placeholder="Security Question (e.g., Mom's birth code)" 
                required 
                className="w-full glass-input rounded-2xl px-6 py-4 outline-none transition-all placeholder:text-white/20 text-white font-semibold" 
                onChange={e => setSetupData({...setupData, quest: e.target.value})} 
              />
            </div>
            <div className="relative group">
              <input 
                type="text" 
                placeholder="Security Answer" 
                required 
                className="w-full glass-input rounded-2xl px-6 py-4 outline-none transition-all placeholder:text-white/20 text-white font-semibold" 
                onChange={e => setSetupData({...setupData, ans: e.target.value})} 
              />
            </div>
            <motion.button 
              id="init_vault_button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              animate={{ borderRadius: ["1.5rem", "2rem", "1.75rem", "1.5rem"] }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
              className={`w-full bg-gradient-to-r ${theme.gradient} text-white font-black py-4 rounded-2xl shadow-lg ${theme.buttonGlow} transition-all flex items-center justify-center gap-2 cursor-pointer border border-white/10`}
            >
              INITIALIZE VAULT <ArrowRight className="w-5 h-5" />
            </motion.button>
          </form>
        ) : (
          <form onSubmit={handleUnlockSubmit} className="space-y-6">
            <div className="relative group">
              <input 
                type="password" 
                value={password} 
                onChange={e => setPassword(e.target.value)} 
                placeholder="••••••••" 
                className="w-full glass-input rounded-2xl px-5 py-5 text-center text-3xl tracking-[0.5em] focus:bg-white/[0.04] outline-none transition-all placeholder:text-white/10 text-white font-bold" 
                autoFocus 
              />
              <Lock className="absolute right-5 top-1/2 -translate-y-1/2 w-5 h-5 text-white/20 group-focus-within:text-white/50 transition-colors" />
            </div>
            <motion.button 
              id="unlock_system_button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              animate={{ borderRadius: ["22% 78% 33% 67% / 54% 34% 66% 46%", "50% 50% 50% 50%", "78% 22% 67% 33% / 46% 66% 34% 54%", "22% 78% 33% 67% / 54% 34% 66% 46%"] }}
              transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
              className={`w-full bg-gradient-to-r ${theme.gradient} text-white font-black py-4 shadow-xl ${theme.buttonGlow} transition-all flex items-center justify-center gap-2 cursor-pointer border border-white/15`}
            >
              UNLOCK SYSTEM <Fingerprint className="w-5 h-5" />
            </motion.button>
            {failedAttempts > 0 && (
              <p className="text-center text-rose-400 text-xs font-bold uppercase tracking-widest animate-pulse">
                {failedAttempts}/10 Attempts Remaining
              </p>
            )}
          </form>
        )}
      </motion.div>

      <AnimatePresence>
        {alertMsg && <Toast message={alertMsg.msg} type={alertMsg.type} onClose={() => setAlertMsg(null)} />}
      </AnimatePresence>
    </div>
  );
}

function Dashboard() {
  const { lock, isSetup, liquidTheme, updateTheme } = useContext(AuthContext);
  const theme = GRAPHIC_THEMES[liquidTheme] || GRAPHIC_THEMES.nebula;
  const [tab, setTab] = useState('home');
  const [scans, setScans] = useState<any[]>(JSON.parse(localStorage.getItem('mv_scans') || '[]'));
  const [isScanning, setIsScanning] = useState(false);
  const [chat, setChat] = useState<any[]>([]);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [aiEngine, setAiEngine] = useState<'gemini' | 'pollinations'>(localStorage.getItem('mv_ai_engine') as any || 'gemini');
  const [medicines, setMedicines] = useState<any[]>(JSON.parse(localStorage.getItem('mv_meds') || '[]'));
  const [isListening, setIsListening] = useState(false);
  
  // Custom states replacing browser dialogs/alerts
  const [alertMsg, setAlertMsg] = useState<{ msg: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [addMedOpen, setAddMedOpen] = useState(false);
  const [newMed, setNewMed] = useState({ name: '', expiry: '' });
  const [confirmClearOpen, setConfirmClearOpen] = useState(false);
  
  // Inline BMI calculator states
  const [bmiWeight, setBmiWeight] = useState(70);
  const [bmiHeight, setBmiHeight] = useState(175);
  const [bmiResult, setBmiResult] = useState<number | null>(null);

  const displayToast = (msg: string, type: 'success' | 'error' | 'info' = 'info') => {
    setAlertMsg({ msg, type });
  };

  useEffect(() => {
    localStorage.setItem('mv_ai_engine', aiEngine);
  }, [aiEngine]);

  useEffect(() => {
    localStorage.setItem('mv_meds', JSON.stringify(medicines));
    checkExpiries();
  }, [medicines]);

  const checkExpiries = () => {
    const now = new Date();
    medicines.forEach(med => {
      const exp = new Date(med.expiry);
      const diff = exp.getTime() - now.getTime();
      const days = diff / (1000 * 3600 * 24);
      if (days < 0) {
        sendNotification(`EXPIRED: ${med.name}`, "This medicine has expired. Please dispose of it safely.");
      } else if (days < 30) {
        sendNotification(`NEAR EXPIRY: ${med.name}`, `Expires in ${Math.round(days)} days.`);
      }
    });
  };

  const sendNotification = (title: string, body: string) => {
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification(title, { body });
    }
  };

  const startSTT = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      displayToast("Speech to Text is not supported on this browser.", "error");
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-IN';
    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setQuery(transcript);
    };
    recognition.start();
  };

  const speakText = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'hi-IN';
    window.speechSynthesis.speak(utterance);
  };

  const speakHindi = async (text: string) => {
    if (!text) return;
    try {
      const cleanText = text.replace(/[^\u0900-\u097F\s0-9a-zA-Z,.]/g, '').slice(0, 400);
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: cleanText }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
          },
        },
      });
      
      const part = response.candidates?.[0]?.content?.parts?.[0];
      const base64Audio = part?.inlineData?.data;
      
      if (base64Audio) {
        const binaryString = atob(base64Audio);
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }
        
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        const audioBuffer = audioContext.createBuffer(1, bytes.length / 2, 24000);
        const channelData = audioBuffer.getChannelData(0);
        
        const view = new DataView(bytes.buffer);
        for (let i = 0; i < channelData.length; i++) {
          if (i * 2 + 1 < bytes.length) {
            channelData[i] = view.getInt16(i * 2, true) / 32768;
          }
        }
        
        const source = audioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioContext.destination);
        source.start();
        displayToast("Playing regional synthesized report summary", "success");
      } else {
        // Fallback standard speaking
        speakText(cleanText);
      }
    } catch (e) {
      console.error(e);
      // Fallback
      speakText(text);
    }
  };

  const handleScan = async (e: any) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsScanning(true);
    
    try {
      let fileData = '';
      let mimeType = file.type || "image/jpeg";

      if (file.type === 'text/plain') {
        fileData = await file.text();
      } else {
        const reader = new FileReader();
        fileData = await new Promise((resolve) => {
          reader.onload = (ev) => resolve((ev.target?.result as string).split(',')[1]);
          reader.readAsDataURL(file);
        });
      }

      const prompt = `Analyze this medical document (${file.name}). 
      1. Extract ALL items into a structured list (Name, Qty, MRP, Rate, Discount, Total).
      2. Extract hospitalName, date, totalAmount, taxAmount, discountAmount.
      3. Extract EVERY SINGLE LINE of text into 'allLines' array.
      4. Extract the entire text into 'fullRawText'.
      5. Provide a short Hinglish summary.
      Ensure 100% accuracy for the inbuilt Excel sheet view.`;

      const res = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: file.type === 'text/plain'
          ? [{ text: prompt }, { text: fileData }]
          : [{ 
              parts: [
                { inlineData: { data: fileData, mimeType: mimeType } }, 
                { text: prompt }
              ] 
            }],
        config: { responseMimeType: "application/json", responseSchema: OCR_SCHEMA }
      });

      const data = JSON.parse(res.text || "{}");
      
      const newScan = { 
        id: Date.now(), 
        date: new Date().toISOString(), 
        ...data, 
        image: file.type === 'text/plain' ? null : `data:${mimeType};base64,${fileData}`, 
        fileType: mimeType 
      };

      let updatedScans = [newScan, ...scans];
      
      // Prune old images to save localStorage space (keep only last 4 images)
      updatedScans = updatedScans.map((s, idx) => {
        if (idx >= 4 && s.image) {
          return { ...s, image: null };
        }
        return s;
      });

      if (updatedScans.length > 40) {
        updatedScans = updatedScans.slice(0, 40);
      }

      try {
        localStorage.setItem('mv_scans', JSON.stringify(updatedScans));
        setScans(updatedScans);
      } catch (storageError) {
        const minimalScans = updatedScans.map((s, idx) => idx === 0 ? s : { ...s, image: null });
        localStorage.setItem('mv_scans', JSON.stringify(minimalScans));
        setScans(minimalScans);
        displayToast("Storage full. Purged old graphic data.", "info");
      }

      confetti({
        particleCount: 120,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#c084fc', '#f472b6', '#22d3ee', '#ffffff']
      });
      displayToast("Analysis successfully stored in glass fortress!", "success");
      if (data.summaryHindi) speakHindi(data.summaryHindi);
    } catch (err) {
      console.error(err);
      displayToast("Analysis failed. Try a clearer document image.", "error");
    } finally { setIsScanning(false); }
  };

  const exportSinglePDF = (s: any) => {
    try {
      const doc = new jsPDF();
      doc.setFontSize(22);
      doc.text("MediVault Fortress AI Report", 20, 20);
      doc.setFontSize(12);
      doc.text(`Hospital: ${s.fields?.hospitalName || 'N/A'}`, 20, 35);
      doc.text(`Date: ${new Date(s.date).toLocaleDateString()}`, 20, 42);
      doc.text(`Type: ${s.documentType}`, 20, 49);
      doc.text(`Total Amount: INR ${s.fields?.totalAmount}`, 20, 56);
      
      doc.setFontSize(14);
      doc.text("Summary (Hindi):", 20, 70);
      doc.setFontSize(10);
      const splitSummary = doc.splitTextToSize(s.summaryHindi, 170);
      doc.text(splitSummary, 20, 77);

      doc.setFontSize(14);
      doc.text("Items Table:", 20, 100);
      let y = 110;
      doc.setFontSize(10);
      doc.text("Item Name", 20, y);
      doc.text("Qty", 100, y);
      doc.text("Rate", 130, y);
      doc.text("Total", 160, y);
      y += 7;
      doc.line(20, y-5, 190, y-5);

      (s.fields.items || []).forEach((item: any) => {
        if (y > 270) { doc.addPage(); y = 20; }
        doc.text(String(item.name).substring(0, 40), 20, y);
        doc.text(String(item.qty), 100, y);
        doc.text(String(item.rate), 130, y);
        doc.text(String(item.total), 160, y);
        y += 7;
      });

      doc.save(`MediVault_${s.fields?.hospitalName || 'Report'}_${Date.now()}.pdf`);
      displayToast("Downloaded beautiful PDF ledger", "success");
    } catch (error) {
      displayToast("Failed PDF Generation", "error");
    }
  };

  const shareScan = async (s: any) => {
    const text = `MediVault Report: ${s.fields?.hospitalName}\nTotal: ₹${s.fields?.totalAmount}\nSummary: ${s.summaryHindi}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'MediVault Medical Report',
          text: text,
          url: window.location.href
        });
      } catch (err) { console.error(err); }
    } else {
      navigator.clipboard.writeText(text);
      displayToast("Report copied to private secure clipboard!", "success");
    }
  };

  const handleChat = async (e: any) => {
    e.preventDefault();
    if (!query.trim()) return;
    const userMsg = { role: 'user', text: query };
    setChat([...chat, userMsg]);
    setQuery('');
    setLoading(true);

    const compactContext = scans.map(s => ({
      hospital: s.fields?.hospitalName,
      date: s.date,
      total: s.fields?.totalAmount,
      summary: s.summaryHindi,
      items: scans.indexOf(s) < 2 ? s.fields?.items?.map((i: any) => i.name) : undefined
    }));

    try {
      const res = aiEngine === 'gemini' 
        ? await ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: query,
            config: { systemInstruction: `MediVault Assistant. System is highly optimized for medicinal parsing. Context: ${JSON.stringify(compactContext)}. Respond in cozy Hinglish.` }
          })
        : await (await fetch(`https://text.pollinations.ai/${encodeURIComponent(query + " (Context: " + JSON.stringify(compactContext) + ") Respond in Cozy Hinglish.")}`)).json();
      
      const text = aiEngine === 'gemini' ? res.text : (res as any).text || res;
      setChat(prev => [...prev, { role: 'ai', text }]);
      speakHindi(text);
    } catch (err) {
      displayToast("Chat assistance briefly offline", "error");
    } finally { setLoading(false); }
  };

  const exportExcel = () => {
    try {
      const flattenedData = scans.flatMap(s => 
        (s.fields.items || [{}]).map((item: any) => ({
          Date: new Date(s.date).toLocaleDateString(),
          Hospital: s.fields.hospitalName,
          Type: s.documentType,
          Item: item.name || 'N/A',
          Qty: item.qty || 0,
          MRP: item.mrp || 0,
          Rate: item.rate || 0,
          Discount: item.discount || 0,
          Total: item.total || 0,
          BillTotal: s.fields.totalAmount,
          Summary_Hindi: s.summaryHindi
        }))
      );
      const ws = XLSX.utils.json_to_sheet(flattenedData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "MediVault_Full_Report");
      XLSX.writeFile(wb, "MediVault_Medical_Report.xlsx");
      displayToast("Exported secure excel database", "success");
    } catch (e) {
      displayToast("Excel library error", "error");
    }
  };

  const exportJSON = () => {
    try {
      const blob = new Blob([JSON.stringify(scans, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = "MediVault_Backup.json";
      a.click();
    } catch (e) {
      displayToast("Export JSON failed", "error");
    }
  };

  const exportTXT = () => {
    const text = scans.map(s => `
--- ${s.fields.hospitalName} (${new Date(s.date).toLocaleDateString()}) ---
Type: ${s.documentType}
Total: ₹${s.fields.totalAmount}
Items:
${(s.fields.items || []).map((i: any) => `- ${i.name}: ${i.qty} x ${i.rate} = ${i.total}`).join('\n')}
Summary: ${s.summaryHindi}
`).join('\n\n');
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = "MediVault_Summary.txt";
    a.click();
  };

  const backupAll = () => {
    exportExcel();
    exportJSON();
    exportTXT();
    confetti({
      particleCount: 80,
      spread: 50,
      origin: { y: 0.6 }
    });
  };

  const addMedicine = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMed.name || !newMed.expiry) {
      displayToast("Complete cabinet details first", "error");
      return;
    }
    setMedicines([...medicines, { id: Date.now(), name: newMed.name, expiry: newMed.expiry }]);
    setNewMed({ name: '', expiry: '' });
    setAddMedOpen(false);
    displayToast(`${newMed.name} added to security cabinet`, "success");
    confetti({ particleCount: 30, spread: 20 });
  };

  const deleteMedicine = (id: number, name: string) => {
    setMedicines(medicines.filter(m => m.id !== id));
    displayToast(`${name} purged from safe tracking`, "info");
  };

  const handleClearScans = () => {
    localStorage.removeItem('mv_scans');
    setScans([]);
    setConfirmClearOpen(false);
    displayToast("Secure vault completely wiped", "success");
  };

  const calculateBMI = () => {
    if (bmiWeight && bmiHeight) {
      const hM = bmiHeight / 100;
      const val = bmiWeight / (hM * hM);
      setBmiResult(Number(val.toFixed(1)));
      displayToast(`BMI calculated: ${val.toFixed(1)}`, "success");
    }
  };

  const getBMICategory = (val: number) => {
    if (val < 18.5) return { label: 'Underweight', color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/30' };
    if (val < 25) return { label: 'Optimal Height-Weight Ratio', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' };
    if (val < 30) return { label: 'Moderately Overweight', color: 'text-orange-400 bg-orange-500/10 border-orange-500/30' };
    return { label: 'Clinically Hyper-Weight', color: 'text-rose-400 bg-rose-500/10 border-rose-500/30' };
  };

  return (
    <div className="relative min-h-screen text-white flex flex-col safe-area-inset overflow-hidden font-sans transition-colors duration-1000">
      <LiquidBackground />
      <FloatingBubbles />

      {/* Glossy Header Bar */}
      <header className="relative p-5 flex justify-between items-center border-b border-white/[0.06] glass-panel satin-sheen sticky top-0 z-40 shadow-[0_12px_44px_rgba(0,0,0,0.35)]">
        <div className={`absolute top-0 inset-x-0 h-[1.8px] bg-gradient-to-r ${theme.ambient} transition-all duration-1000`} />
        <div className="flex items-center gap-3">
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className={`w-10 h-10 bg-gradient-to-tr ${theme.gradient} rounded-xl flex items-center justify-center shadow-lg ${theme.buttonGlow} transition-all duration-1000`}
          >
            <Shield className="w-5 h-5 text-white" />
          </motion.div>
          <div>
            <h2 className="font-black text-lg tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-indigo-100 to-indigo-150">MediVault</h2>
            <p className="text-[8.5px] uppercase tracking-widest font-extrabold text-white/40">Glassmorphic Ledger</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full ${theme.secondary.replace('text-', 'bg-')} animate-pulse-soft shadow-[0_0_12px_rgba(255,255,255,0.4)]`} />
          <p className={`text-[10px] uppercase font-extrabold ${theme.secondary} tracking-wider transition-colors duration-1000`}>Secured Vault</p>
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={lock} 
            className="p-2 ml-2 text-white/50 hover:text-rose-450 hover:bg-rose-500/15 rounded-xl transition-all cursor-pointer"
          >
            <LogOut className="w-5 h-5" />
          </motion.button>
        </div>
      </header>

      {/* Main Glassmorphic Wrapper */}
      <main id="dashboard_main_viewport" className="flex-1 overflow-y-auto p-6 pb-36 custom-scrollbar relative z-10">
        
        {isScanning && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`bg-gradient-to-r ${theme.gradient}/10 border ${theme.cardBorder} p-5 rounded-3xl mb-8 flex items-center gap-4 shadow-xl backdrop-blur-md animate-pulse-soft`}
          >
            <div className={`w-6 h-6 border-2 ${theme.secondary} border-t-transparent rounded-full animate-spin`} />
            <p className={`${theme.secondary} font-extrabold text-sm uppercase tracking-wider`}>Fortress AI Transcribing & Parsing Ledger...</p>
          </motion.div>
        )}

        <AnimatePresence mode="wait">
          {tab === 'home' && (
            <motion.div 
              key="tab-home"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="space-y-8"
            >
              {/* Stats Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div className="relative glass-panel satin-sheen p-6 rounded-[2rem] shadow-[0_12px_32px_rgba(0,0,0,0.15)] overflow-hidden transition-all duration-500">
                  <div className={`absolute top-0 left-0 w-1.5 h-full bg-gradient-to-b ${theme.ambient}`} />
                  <p className="text-[10px] font-black text-white/40 uppercase tracking-widest mb-1 font-mono">Consolidated Spends</p>
                  <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-indigo-50 to-indigo-150">
                    ₹{scans.reduce((a, b) => a + (b.fields?.totalAmount || 0), 0).toLocaleString()}
                  </p>
                </div>
                <div className="relative glass-panel satin-sheen p-6 rounded-[2rem] shadow-[0_12px_32px_rgba(0,0,0,0.15)] overflow-hidden transition-all duration-500">
                  <div className={`absolute top-0 left-0 w-1.5 h-full bg-gradient-to-b ${theme.ambient}`} />
                  <p className="text-[10px] font-black text-white/40 uppercase tracking-widest mb-1 font-mono">Secure Vaulted Records</p>
                  <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-indigo-50 to-indigo-150">
                    {scans.length} Items
                  </p>
                </div>
              </div>

              {/* Liquid Hero Interactive Scanner */}
              <motion.div 
                whileHover={{ scale: 1.01 }}
                className={`relative bg-gradient-to-br ${theme.heroGradient} rounded-[2.5rem] p-8 text-white overflow-hidden shadow-2xl border border-white/10 transition-colors duration-1000`}
              >
                {/* Liquid bubble circles decorative inside the card */}
                <div className="absolute top-12 -right-12 w-48 h-48 bg-white/[0.02] rounded-full blur-2xl pointer-events-none" />
                <div className="absolute -left-12 -bottom-12 w-48 h-48 bg-white/[0.02] rounded-full blur-2xl pointer-events-none" />
                
                <h3 className="text-3xl font-black mb-2 tracking-tight">HOLOGRAPHIC SCAN</h3>
                <p className="text-white/60 text-xs font-semibold mb-6 uppercase tracking-wider">Analyze prescriptions, bills & scans with military grade precision.</p>
                
                <label className={`bg-gradient-to-r ${theme.gradient} text-white px-8 py-4 rounded-2xl font-black text-xs cursor-pointer inline-flex items-center gap-2 ${theme.buttonGlow} hover:shadow-[0_0_25px_rgba(255,255,255,0.06)] transition-all active:scale-95 border border-white/10 uppercase tracking-wider`}>
                  <Camera className="w-4 h-4" /> Import OCR Invoice / PDF
                  <input type="file" className="hidden" accept="image/*,application/pdf" onChange={handleScan} />
                </label>
                <Scan className="absolute right-4 bottom-4 w-36 h-36 text-white/[0.02] pointer-events-none" />
              </motion.div>

              {/* Recent Documents Table List */}
              <div className="space-y-4">
                <div className="flex justify-between items-center px-2">
                  <h3 className={`font-extrabold text-sm uppercase tracking-widest ${theme.secondary} transition-all duration-1000`}>Fortress Ledgers</h3>
                  <div className="flex gap-2">
                    <button onClick={backupAll} className="text-white text-[9px] font-black flex items-center gap-1 bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-full border border-white/10 transition-all uppercase tracking-wider cursor-pointer shadow-sm">
                      Backup All
                    </button>
                    <button onClick={exportExcel} className={`text-white text-[9px] font-black flex items-center gap-1 bg-gradient-to-r ${theme.gradient}/10 hover:${theme.gradient}/25 px-3 py-1.5 rounded-full border ${theme.cardBorder} transition-all uppercase tracking-wider cursor-pointer shadow-sm`}>
                      Export Excel
                    </button>
                  </div>
                </div>
                {scans.slice(0, 4).map(s => (
                  <div key={s.id} className="glass-panel p-5 rounded-3xl flex items-center justify-between hover:bg-white/[0.04] hover:border-white/15 transition-all duration-300 group">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 bg-white/[0.02] rounded-2xl flex items-center justify-center border border-white/[0.06] group-hover:${theme.cardBorder} transition-all duration-500`}>
                        <FileText className={`w-5 h-5 ${theme.secondary} transition-colors duration-1000`} />
                      </div>
                      <div>
                        <h4 className="font-black text-sm text-white/90 truncate w-36">{s.fields?.hospitalName || 'General Record'}</h4>
                        <p className="text-[9px] text-white/40 font-mono tracking-wider mt-0.5">{new Date(s.date).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-black text-transparent bg-clip-text bg-gradient-to-r ${theme.gradient} transition-all duration-1000`}>₹{s.fields?.totalAmount || 0}</p>
                      <button 
                        onClick={() => speakHindi(s.summaryHindi)} 
                        className={`text-[9px] ${theme.secondary} uppercase font-black tracking-widest hover:text-white transition-colors cursor-pointer block ml-auto mt-1`}
                      >
                        Hear Summary
                      </button>
                    </div>
                  </div>
                ))}
                
                {scans.length === 0 && (
                  <div className="backdrop-blur-md bg-white/[0.01] border border-white/[0.05] p-12 rounded-[2rem] text-center text-white/20">
                    <History className="w-12 h-12 mx-auto mb-3 opacity-20" />
                    <p className="font-mono text-xs uppercase tracking-widest">No Medical Ledgers Vaulted</p>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {tab === 'vault' && (
            <motion.div 
              key="tab-vault"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="space-y-6"
            >
              <h3 className="font-extrabold text-lg text-indigo-300 uppercase tracking-widest px-2">Document Ledger Vault</h3>
              <div className="grid grid-cols-1 gap-6">
                {scans.map(s => (
                  <div key={s.id} className="backdrop-blur-3xl bg-white/[0.02] border border-white/[0.06] rounded-[2.5rem] overflow-hidden shadow-xl hover:shadow-[0_20px_50px_rgba(0,0,0,0.3)] transition-all">
                    {/* Render Image with fine glass opacity */}
                    <div className="h-44 bg-black/40 relative flex items-center justify-center overflow-hidden border-b border-white/[0.05]">
                      {s.fileType?.includes('pdf') ? (
                        <div className="flex flex-col items-center gap-2 text-white/20">
                          <FileText className="w-14 h-14" />
                          <span className="text-[9px] font-black uppercase tracking-widest font-mono">SECURED PDF CLOUD DATA</span>
                        </div>
                      ) : (
                        <img src={s.image} className="w-full h-full object-cover opacity-60 filter saturate-125" referrerPolicy="no-referrer" />
                      )}
                      <div className="absolute top-5 left-5 bg-gradient-to-r from-fuchsia-600 to-pink-600 text-white text-[9px] font-black px-3 py-1 rounded-full uppercase tracking-wider">
                        {s.documentType}
                      </div>
                    </div>

                    <div className="p-6 md:p-8">
                      <h4 className="font-black text-2xl text-white/90 mb-1 leading-none">{s.fields?.hospitalName}</h4>
                      <p className="text-[10px] text-indigo-300 font-black mb-4 uppercase tracking-wider">{new Date(s.date).toLocaleDateString()}</p>
                      <p className="text-xl text-cyan-400 font-extrabold mb-4">₹{s.fields?.totalAmount}</p>
                      
                      <div className="bg-white/[0.02] border border-white/[0.06] p-4 rounded-2xl mb-6 text-xs text-white/70 italic leading-relaxed">
                        "{s.summaryHindi}"
                      </div>
                      
                      {/* Fully Custom Inbuilt Excel View */}
                      <p className="text-[10px] font-mono uppercase tracking-widest text-white/30 mb-2 px-1">Ledger SpreadSheet Table</p>
                      <div className="mb-6 overflow-x-auto rounded-2xl border border-white/[0.08] bg-[#020205]/40 shadow-inner">
                        <table className="w-full text-xs text-left border-collapse min-w-[500px]">
                          <thead>
                            <tr className="border-b border-white/[0.08] text-white/40 uppercase font-black bg-white/[0.03]">
                              <th className="p-3">Item Name</th>
                              <th className="p-3 text-center">Qty</th>
                              <th className="p-3 text-center">MRP</th>
                              <th className="p-3 text-center">Rate</th>
                              <th className="p-3 text-right">Total</th>
                            </tr>
                          </thead>
                          <tbody>
                            {(s.fields.items || []).map((item: any, idx: number) => (
                              <tr key={idx} className="border-b border-white/[0.03] hover:bg-white/[0.03] transition-colors">
                                <td className="p-3 font-semibold text-white/80">{item.name}</td>
                                <td className="p-3 text-center text-white/60 font-mono">{item.qty}</td>
                                <td className="p-3 text-center text-white/60 font-mono">₹{item.mrp}</td>
                                <td className="p-3 text-center text-white/60 font-mono">₹{item.rate}</td>
                                <td className="p-3 text-right font-black text-fuchsia-400 font-mono">₹{item.total}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>

                      <div className="flex flex-wrap gap-2 mb-4">
                        <button onClick={() => speakHindi(s.summaryHindi)} className="flex-1 bg-gradient-to-r from-fuchsia-500/20 to-pink-500/20 text-fuchsia-300 border border-fuchsia-500/35 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest cursor-pointer hover:bg-fuchsia-500/30 transition-all">
                          Read Aloud (Hindi/Hinglish)
                        </button>
                        <button onClick={() => exportSinglePDF(s)} className="p-3 bg-white/[0.04] text-white/80 border border-white/10 hover:border-purple-500/40 hover:text-purple-300 rounded-xl transition-all cursor-pointer" title="PDF Report">
                          <FileText className="w-4 h-4" />
                        </button>
                        <button onClick={() => shareScan(s)} className="p-3 bg-white/[0.04] text-white/80 border border-white/10 hover:border-cyan-500/40 hover:text-cyan-300 rounded-xl transition-all cursor-pointer" title="Share Ledger">
                          <Share2 className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Expandable Technical Sheets */}
                      <div className="space-y-3">
                        <details className="group">
                          <summary className="flex items-center justify-between p-4 bg-white/[0.02] hover:bg-white/[0.04] border border-white/[0.06] rounded-2xl cursor-pointer transition-colors">
                            <span className="text-[10px] font-mono uppercase tracking-widest text-white/40">OCR Categories Array</span>
                            <ChevronRight className="w-4 h-4 text-white/30 group-open:rotate-90 transition-transform" />
                          </summary>
                          <div className="mt-2 p-4 bg-black/50 rounded-2xl border border-white/[0.06] overflow-x-auto">
                            <table className="w-full text-[10px] border-collapse font-mono">
                              <thead>
                                <tr className="border-b border-white/10 text-white/20 uppercase font-bold">
                                  <th className="text-left py-2">Parsed Text</th>
                                  <th className="text-right py-2">Category Flag</th>
                                </tr>
                              </thead>
                              <tbody>
                                {(s.fields.allLines || []).map((line: any, lidx: number) => (
                                  <tr key={lidx} className="border-b border-white/[0.03]">
                                    <td className="py-2 text-white/60">{line.originalText}</td>
                                    <td className="py-2 text-right text-fuchsia-400/80 italic">{line.interpretedCategory}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </details>

                        <details className="group">
                          <summary className="flex items-center justify-between p-4 bg-white/[0.02] hover:bg-white/[0.04] border border-white/[0.06] rounded-2xl cursor-pointer transition-colors">
                            <span className="text-[10px] font-mono uppercase tracking-widest text-white/40">Full Raw Document Text</span>
                            <ChevronRight className="w-4 h-4 text-white/30 group-open:rotate-90 transition-transform" />
                          </summary>
                          <div className="mt-2 p-4 bg-black/50 rounded-2xl border border-white/[0.06]">
                            <pre className="text-[10px] text-white/50 whitespace-pre-wrap font-mono leading-relaxed max-h-60 overflow-y-auto">
                              {s.fullRawText}
                            </pre>
                          </div>
                        </details>
                      </div>
                    </div>
                  </div>
                ))}

                {scans.length === 0 && (
                  <div className="backdrop-blur-md bg-white/[0.01] border border-white/[0.05] p-20 rounded-[2.5rem] text-center text-white/20">
                    <History className="w-16 h-16 mx-auto mb-4 opacity-10" />
                    <p className="font-mono text-xs uppercase tracking-widest leading-loose">Medical ledger vault is empty.<br/>Upload documents to populate ledger sheets.</p>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {tab === 'meds' && (
            <motion.div 
              key="tab-meds"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="space-y-6"
            >
              <div className="flex justify-between items-center px-2">
                <div>
                  <h3 className="font-extrabold text-lg text-indigo-300 uppercase tracking-widest">Medicine safe</h3>
                  <p className="text-[9px] font-black uppercase text-white/40 font-mono">Expiry & Storage Cabinet</p>
                </div>
                <button 
                  onClick={() => setAddMedOpen(true)} 
                  className="bg-gradient-to-tr from-fuchsia-500 to-indigo-500 hover:shadow-[0_0_15px_rgba(168,85,247,0.3)] text-white p-3 rounded-2xl cursor-pointer transition-all border border-white/10"
                >
                  <Plus className="w-5 h-5" />
                </button>
              </div>

              {/* Slider list of tracked medicines */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {medicines.map(m => {
                  const days = Math.round((new Date(m.expiry).getTime() - new Date().getTime()) / (1000 * 3600 * 24));
                  const isExpired = days < 0;
                  const isNear = days >= 0 && days < 30;

                  return (
                    <div key={m.id} className="relative backdrop-blur-2xl bg-white/[0.02] hover:bg-white/[0.04] border border-white/[0.06] p-6 rounded-3xl flex justify-between items-center transition-all group">
                      <div className="absolute top-0 left-0 w-1.5 h-full rounded-l-3xl bg-gradient-to-b from-purple-500 to-cyan-500" />
                      <div>
                        <h4 className="font-black text-lg text-white/95">{m.name}</h4>
                        <p className="text-[10px] text-white/40 font-mono font-bold uppercase tracking-widest mt-1">Expiry Date: {m.expiry}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`px-4 py-2 rounded-xl text-[9px] font-mono font-black uppercase tracking-wider ${isExpired ? 'bg-rose-500/10 text-rose-350 border border-rose-500/25' : isNear ? 'bg-orange-500/10 text-orange-350 border border-orange-500/25' : 'bg-emerald-500/10 text-emerald-350 border border-emerald-500/25'}`}>
                          {isExpired ? 'EXPIRED' : `${days} Days Left`}
                        </span>
                        <button 
                          onClick={() => deleteMedicine(m.id, m.name)} 
                          className="p-2 opacity-50 group-hover:opacity-100 hover:text-rose-400 transition-all rounded-xl cursor-pointer"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}

                {medicines.length === 0 && (
                  <div className="md:col-span-2 backdrop-blur-md bg-white/[0.01] border border-white/[0.05] p-20 rounded-[2.5rem] text-center text-white/20">
                    <Pill className="w-16 h-16 mx-auto mb-4 opacity-10" />
                    <p className="font-mono text-xs uppercase tracking-widest leading-loose">Medicine cabinet currently bare</p>
                  </div>
                )}
              </div>

              {/* Add Medicine Glass Sheet slide-in */}
              <AnimatePresence>
                {addMedOpen && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-[110] p-6"
                  >
                    <motion.div 
                      initial={{ scale: 0.95, y: 30 }}
                      animate={{ scale: 1, y: 0 }}
                      exit={{ scale: 0.95, y: 30 }}
                      className="backdrop-blur-3xl bg-white/[0.04] border border-white/[0.1] w-full max-w-md rounded-[2.5rem] p-8 shadow-[0_32px_64px_rgba(0,0,0,0.5)] relative overflow-hidden"
                    >
                      <div className="absolute top-0 inset-x-0 h-[1.5px] bg-gradient-to-r from-transparent via-fuchsia-500/40 is via-cyan-500/40 to-transparent" />
                      <div className="flex justify-between items-center mb-6">
                        <h4 className="text-xl font-black uppercase tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-indigo-200 to-fuchsia-300">Track New Medicine</h4>
                        <button onClick={() => setAddMedOpen(false)} className="text-white/40 hover:text-white p-1">
                          <X className="w-6 h-6" />
                        </button>
                      </div>

                      <form onSubmit={addMedicine} className="space-y-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-300 px-1">Medicine Name</label>
                          <input 
                            type="text" 
                            required
                            placeholder="e.g., Cetirizine Hydrochloride" 
                            value={newMed.name}
                            onChange={e => setNewMed({ ...newMed, name: e.target.value })}
                            className="w-full bg-white/[0.03] border border-white/10 hover:border-white/20 focus:border-cyan-500/40 rounded-xl px-5 py-3 outline-none text-white text-sm"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-300 px-1">Expiration Stamp</label>
                          <input 
                            type="date" 
                            required
                            value={newMed.expiry}
                            onChange={e => setNewMed({ ...newMed, expiry: e.target.value })}
                            className="w-full bg-white/[0.03] border border-white/10 hover:border-white/20 focus:border-cyan-500/40 rounded-xl px-5 py-3 outline-none text-white text-sm"
                          />
                        </div>
                        <motion.button 
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          type="submit" 
                          className="w-full bg-gradient-to-r from-fuchsia-500 to-indigo-500 text-white py-4 rounded-xl text-xs font-black uppercase tracking-wider border border-white/10 cursor-pointer shadow-lg hover:shadow-[0_0_15px_rgba(168,85,247,0.3)] mt-4"
                        >
                          Lock Into Cabinet
                        </motion.button>
                      </form>
                    </motion.div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )}

          {tab === 'health' && (
            <motion.div 
              key="tab-health"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="space-y-6"
            >
              <h3 className="font-extrabold text-lg text-indigo-300 uppercase tracking-widest px-2">Health Matrix Suite</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Fully Customized Inline BMI Calculator */}
                <div className="backdrop-blur-3xl bg-white/[0.02] border border-white/[0.06] p-6 rounded-[2rem] relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-2xl pointer-events-none" />
                  <div className="flex items-center gap-3 mb-6">
                    <TrendingUp className="w-5 h-5 text-cyan-400" />
                    <div>
                      <h4 className="font-black text-sm uppercase tracking-wider text-white">Liquid BMI Calculator</h4>
                      <p className="text-[8px] uppercase tracking-widest font-mono text-white/40">Height & Weight Sync</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs font-mono">
                        <span className="text-white/60">Mass:</span>
                        <span className="text-cyan-400 font-extrabold">{bmiWeight} kg</span>
                      </div>
                      <input 
                        type="range" 
                        min="30" 
                        max="160" 
                        value={bmiWeight} 
                        onChange={e => { setBmiWeight(Number(e.target.value)); setBmiResult(null); }}
                        className="w-full accent-cyan-400 cursor-pointer bg-white/10 h-1.5 rounded-full"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-xs font-mono">
                        <span className="text-white/60">Height:</span>
                        <span className="text-fuchsia-400 font-extrabold">{bmiHeight} cm</span>
                      </div>
                      <input 
                        type="range" 
                        min="100" 
                        max="230" 
                        value={bmiHeight} 
                        onChange={e => { setBmiHeight(Number(e.target.value)); setBmiResult(null); }}
                        className="w-full accent-fuchsia-400 cursor-pointer bg-white/10 h-1.5 rounded-full"
                      />
                    </div>

                    <button 
                      onClick={calculateBMI}
                      className="w-full bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest text-cyan-400 transition-all cursor-pointer"
                    >
                      Process Health Scale
                    </button>

                    {bmiResult && (
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="p-4 rounded-2xl border bg-[#020205]/40 text-center space-y-1 mt-4"
                      >
                        <p className="text-[10px] font-mono text-white/30 uppercase tracking-widest">Calculated Body Mass Index</p>
                        <p className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-fuchsia-400">{bmiResult}</p>
                        <p className={`text-[10px] font-bold uppercase py-1 px-3 rounded-full inline-block mt-1 font-mono border ${getBMICategory(bmiResult).color}`}>
                          {getBMICategory(bmiResult).label}
                        </p>
                      </motion.div>
                    )}
                  </div>
                </div>

                {/* Symptom checker card details */}
                <div className="backdrop-blur-3xl bg-white/[0.02] border border-white/[0.06] p-6 rounded-[2rem] relative overflow-hidden flex flex-col justify-between">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-fuchsia-500/5 rounded-full blur-2xl pointer-events-none" />
                  <div>
                    <div className="flex items-center gap-3 mb-4">
                      <AlertCircle className="w-5 h-5 text-indigo-400" />
                      <div>
                        <h4 className="font-black text-sm uppercase tracking-wider text-white">Symptom Checker</h4>
                        <p className="text-[8px] uppercase tracking-widest font-mono text-white/40">Fortress Assistant Gateway</p>
                      </div>
                    </div>
                    <p className="text-xs text-white/50 leading-relaxed mb-6 mt-1">
                      Encountering unexpected wellness markers or chronic syndromes? Leverage our deep neural speech and text companion for custom regional breakdowns.
                    </p>
                  </div>
                  <button 
                    onClick={() => setTab('chat')} 
                    className="w-full bg-gradient-to-r from-fuchsia-500/20 to-indigo-500/20 text-indigo-300 border border-indigo-500/35 hover:bg-gradient-to-r hover:from-fuchsia-500/30 hover:to-indigo-500/30 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest text-center transition-all cursor-pointer"
                  >
                    Launch Smart Dialog
                  </button>
                </div>
              </div>

              {/* Health Trend AreaChart */}
              <div className="backdrop-blur-3xl bg-white/[0.02] border border-white/[0.06] p-6 rounded-[2.5rem] relative">
                <h4 className="font-black text-sm text-white/90 uppercase tracking-widest mb-6 font-mono">Invoice Financial Outflows</h4>
                <div className="h-56">
                  {scans.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={scans.map(s => ({ date: new Date(s.date).toLocaleDateString(), amount: s.fields?.totalAmount || 0 }))}>
                        <defs>
                          <linearGradient id="colorAmt" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#d946ef" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                        <XAxis dataKey="date" stroke="rgba(255,255,255,0.3)" style={{ fontSize: '9px', fontFamily: 'monospace' }} />
                        <YAxis stroke="rgba(255,255,255,0.3)" style={{ fontSize: '9px', fontFamily: 'monospace' }} />
                        <Tooltip contentStyle={{ backgroundColor: 'rgba(3,3,13,0.9)', borderRadius: '16px', border: '1px solid rgba(255,255,255,0.1)', color: '#fff', fontSize: '11px', fontFamily: 'sans-serif' }} />
                        <Area type="monotone" dataKey="amount" stroke="url(#colorAmt)" fillOpacity={1} fill="url(#colorAmt)" strokeWidth={2.5} />
                      </AreaChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-full flex items-center justify-center text-white/20 font-mono text-xs uppercase tracking-widest">
                      Insert logs to render analytics
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {tab === 'chat' && (
            <motion.div 
              key="tab-chat"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="h-[calc(100vh-270px)] min-h-[400px] flex flex-col backdrop-blur-3xl bg-white/[0.01] border border-white/[0.06] rounded-[2.5rem] overflow-hidden relative shadow-2xl"
            >
              {/* Voice pulse indicator decorative inside Chat */}
              {isListening && (
                <div className="absolute inset-0 bg-indigo-500/[0.03] animate-pulse pointer-events-none z-0" />
              )}

              <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar relative z-10">
                {chat.map((m, i) => (
                  <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] px-5 py-4 rounded-2xl text-xs leading-relaxed ${m.role === 'user' ? 'bg-gradient-to-r from-fuchsia-500/20 via-purple-500/20 to-indigo-500/20 text-white font-semibold border border-fuchsia-500/30 rounded-tr-none shadow-[0_4px_16px_rgba(168,85,247,0.15)]' : 'bg-white/[0.04] border border-white/[0.08] text-white/95 rounded-tl-none'}`}>
                      {m.text}
                    </div>
                  </div>
                ))}
                
                {chat.length === 0 && (
                  <div className="h-full flex flex-col items-center justify-center text-center text-white/20 p-10 select-none">
                    <MessageSquare className="w-12 h-12 mb-3 opacity-10" />
                    <p className="font-mono text-xs uppercase tracking-widest mb-1">Aura Companion Sandbox</p>
                    <p className="text-[10px] text-white/40 max-w-xs uppercase font-semibold">Inquire about spends, medication details, or symptoms in Hindi/Hinglish.</p>
                  </div>
                )}
                {loading && (
                  <div className="flex items-center gap-2 p-3 bg-white/[0.02] border border-white/[0.06] rounded-xl w-32">
                    <div className="w-5 h-5 border-2 border-fuchsia-500 border-t-transparent rounded-full animate-spin" />
                    <span className="text-[10px] font-mono font-bold text-fuchsia-400 uppercase tracking-widest">Thinking...</span>
                  </div>
                )}
              </div>

              <form onSubmit={handleChat} className="p-5 border-t border-white/[0.06] bg-black/40 relative z-10">
                <div className="flex gap-2">
                  <button 
                    type="button" 
                    onClick={startSTT} 
                    className={`p-4 rounded-full transition-all cursor-pointer ${isListening ? 'bg-rose-500 text-white animate-pulse shadow-[0_0_20px_rgba(239,68,68,0.4)]' : 'bg-white/[0.03] text-white/40 border border-white/10 hover:text-white'}`}
                  >
                    <Mic className="w-5 h-5" />
                  </button>
                  <div className="relative flex-1">
                    <input 
                      type="text" 
                      value={query} 
                      onChange={e => setQuery(e.target.value)} 
                      placeholder="Consult with Aura Fortress..." 
                      className="w-full bg-white/[0.02] border border-white/10 rounded-full px-6 py-4 pr-16 outline-none text-xs text-white placeholder:text-white/20 focus:border-cyan-500/50 focus:bg-white/[0.04] transition-all" 
                    />
                    <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 bg-gradient-to-tr from-fuchsia-500 to-indigo-500 hover:shadow-[0_0_10px_rgba(168,85,247,0.3)] text-white p-2.5 rounded-full cursor-pointer transition-all border border-white/10">
                      <Plus className="w-5 h-5 rotate-45" />
                    </button>
                  </div>
                </div>
              </form>
            </motion.div>
          )}

          {tab === 'settings' && (
            <motion.div 
              key="tab-settings"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="space-y-6 p-2"
            >
              <h3 className={`font-extrabold text-lg ${theme.secondary} uppercase tracking-widest px-2 transition-all duration-1000`}>Fortress Settings</h3>
              
              {/* Dynamic Theme selection container */}
              <div className="bg-white/[0.02] border border-white/[0.06] p-6 rounded-[2rem] space-y-4">
                <h3 className={`text-[10px] font-black ${theme.secondary} uppercase tracking-widest font-mono transition-colors duration-1000`}>Liquid Aesthetics</h3>
                <div className="grid grid-cols-2 gap-3">
                  {Object.entries(GRAPHIC_THEMES).map(([key, t]) => (
                    <button 
                      key={key}
                      onClick={() => updateTheme(key)}
                      className={`relative py-4 rounded-2xl transition-all cursor-pointer border flex flex-col items-center gap-1 overflow-hidden ${liquidTheme === key ? `bg-gradient-to-r ${t.gradient}/15 ${t.cardBorder} shadow-[0_4px_24px_rgba(255,255,255,0.04)]` : 'bg-white/[0.02] border-white/5 hover:bg-white/[0.04] text-white/50'}`}
                    >
                      <span className={`text-[10px] font-black uppercase tracking-wider ${liquidTheme === key ? 'text-white' : 'text-white/40'}`}>
                        {key}
                      </span>
                      <div className={`w-8 h-1.5 bg-gradient-to-r ${t.gradient} rounded-full mt-1.5`} />
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-white/[0.02] border border-white/[0.06] p-6 rounded-[2rem] space-y-4">
                <h3 className={`text-[10px] font-black ${theme.secondary} uppercase tracking-widest font-mono transition-colors duration-1000`}>Cognitive AI Core</h3>
                <div className="grid grid-cols-2 p-1 bg-[#020205]/60 hover:bg-[#020205]/80 border border-white/[0.08] rounded-2xl relative">
                  <button 
                    onClick={() => setAiEngine('gemini')}
                    className={`relative py-3.5 text-[9px] font-black rounded-xl transition-all cursor-pointer uppercase tracking-wider ${aiEngine === 'gemini' ? `bg-gradient-to-r ${theme.gradient}/20 border ${theme.cardBorder} text-white font-bold` : 'text-white/30'}`}
                  >
                    Gemini Pro Core
                  </button>
                  <button 
                    onClick={() => setAiEngine('pollinations')}
                    className={`relative py-3.5 text-[9px] font-black rounded-xl transition-all cursor-pointer uppercase tracking-wider ${aiEngine === 'pollinations' ? `bg-gradient-to-r ${theme.gradient}/20 border ${theme.cardBorder} text-white font-bold` : 'text-white/30'}`}
                  >
                    Pollinations API
                  </button>
                </div>
              </div>

              <div className="bg-white/[0.02] border border-white/[0.06] p-6 rounded-[2rem] space-y-4">
                <h3 className="text-[10px] font-black text-indigo-300 uppercase tracking-widest font-mono">Fortress Broadcasts</h3>
                <button 
                  onClick={() => {
                    Notification.requestPermission().then(permission => {
                      if(permission === 'granted') displayToast("Secure system notifications verified", "success");
                    });
                  }}
                  className="w-full py-4 bg-white/[0.01] hover:bg-white/[0.04] text-cyan-300 border border-cyan-500/20 rounded-xl text-[10px] font-black uppercase tracking-widest cursor-pointer transition-all"
                >
                  Initiate Secure Handshake
                </button>
              </div>

              <div className="bg-white/[0.02] border border-white/[0.06] p-6 rounded-[2rem] space-y-4">
                <h3 className="text-[10px] font-black text-indigo-300 uppercase tracking-widest font-mono">Secure Ledger Purges</h3>
                <button 
                  onClick={() => setConfirmClearOpen(true)}
                  className="w-full py-4 bg-rose-500/10 hover:bg-rose-500/20 text-rose-350 border border-rose-500/25 rounded-xl text-[10px] font-black uppercase tracking-widest cursor-pointer transition-all mb-1"
                >
                  Clear Ledger Records
                </button>
                <button 
                  onClick={() => {
                    localStorage.removeItem('mv_pass_hash');
                    displayToast("Security credentials successfully reset. Locking fortress.", "info");
                    setTimeout(() => window.location.reload(), 1500);
                  }} 
                  className="w-full py-4 bg-white/[0.01] hover:bg-rose-500/20 text-white/50 hover:text-rose-300 border border-white/10 hover:border-rose-500/20 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all cursor-pointer"
                >
                  Reset Master Shield Key
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Floating Capsule Glass Dock Navigation */}
      <nav id="floating_navigation_dock" className="fixed bottom-6 left-6 right-6 backdrop-blur-3xl bg-black/40 border border-white/10 rounded-[2.2rem] p-3 flex justify-around items-center z-50 shadow-[0_20px_50px_rgba(0,0,0,0.4)]">
        <NavBtn active={tab === 'home'} icon={<LayoutDashboard />} label="Dash" onClick={() => setTab('home')} />
        <NavBtn active={tab === 'vault'} icon={<History />} label="Vault" onClick={() => setTab('vault')} />
        <NavBtn active={tab === 'meds'} icon={<Pill />} label="Cabinet" onClick={() => setTab('meds')} />
        <NavBtn active={tab === 'health'} icon={<TrendingUp />} label="Health" onClick={() => setTab('health')} />
        <NavBtn active={tab === 'chat'} icon={<MessageSquare />} label="Assistant" onClick={() => setTab('chat')} />
        <NavBtn active={tab === 'settings'} icon={<Settings />} label="Control" onClick={() => setTab('settings')} />
      </nav>

      {/* Wipe Database Modal */}
      <AnimatePresence>
        {confirmClearOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-md flex items-center justify-center z-[120] p-6"
          >
            <motion.div 
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              className="backdrop-blur-3xl bg-white/[0.04] border border-white/[0.1] w-full max-w-sm rounded-[2rem] p-8 shadow-[0_32px_64px_rgba(0,0,0,0.55)] text-center relative"
            >
              <div className="w-16 h-16 bg-rose-500/10 border border-rose-500/30 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="w-8 h-8 text-rose-450 drop-shadow-[0_0_10px_rgba(239,68,68,0.4)]" />
              </div>
              <h4 className="text-xl font-black uppercase tracking-wider text-rose-350">Confirm Ledger Purge</h4>
              <p className="text-xs text-white/50 mt-3 leading-relaxed">
                This will irretrievably wipe all medical invoices, OCR ledgers, and raw reports from this local application's military vaults.
              </p>
              
              <div className="flex gap-3 mt-6">
                <button 
                  onClick={() => setConfirmClearOpen(false)}
                  className="flex-1 bg-white/[0.04] hover:bg-white/[0.08] py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest text-white border border-white/10 cursor-pointer"
                >
                  Decline
                </button>
                <button 
                  onClick={handleClearScans}
                  className="flex-1 bg-rose-500 hover:bg-rose-600 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest text-white cursor-pointer"
                >
                  Erase Securely
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {alertMsg && <Toast message={alertMsg.msg} type={alertMsg.type} onClose={() => setAlertMsg(null)} />}
      </AnimatePresence>
    </div>
  );
}

function NavBtn({ active, icon, label, onClick }: any) {
  const { liquidTheme } = useContext(AuthContext);
  const theme = GRAPHIC_THEMES[liquidTheme] || GRAPHIC_THEMES.nebula;
  return (
    <button 
      onClick={onClick} 
      className="relative p-3.5 rounded-2xl transition-all cursor-pointer group flex flex-col items-center gap-1 min-w-[50px]"
    >
      <div className={`transition-transform duration-300 ${active ? 'text-white scale-110 drop-shadow-[0_0_8px_rgba(255,255,255,0.4)]' : 'text-white/30 group-hover:text-white/60'}`}>
        {React.cloneElement(icon, { className: 'w-5 h-5' })}
      </div>
      
      {/* Sliding fluid pill indicator background that glows */}
      {active && (
        <motion.div
          layoutId="activeTabGlow"
          className={`absolute inset-0 bg-gradient-to-tr ${theme.gradient}/15 border ${theme.cardBorder} rounded-2xl -z-10 shadow-[0_0_20px_rgba(255,255,255,0.06)]`}
          transition={{ type: "spring", stiffness: 350, damping: 28 }}
        />
      )}
    </button>
  );
}

export default function App() {
  return <AuthProvider><AppContent /></AuthProvider>;
}

function AppContent() {
  const { isAuthenticated, isLocked } = useContext(AuthContext);
  return (!isAuthenticated || isLocked) ? <LockScreen /> : <Dashboard />;
}
