import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // Public API for others to use (Mocking the logic, will be powered by Gemini on frontend)
  app.post("/api/ocr", (req, res) => {
    const { apiKey, image } = req.body;
    if (!apiKey) {
      return res.status(401).json({ error: "API Key required" });
    }
    // In a real production app, this would call Gemini server-side.
    // For this demo, we'll provide a structured response format.
    res.json({
      message: "API endpoint for MediVault OCR. Use the frontend for full integration.",
      status: "ready"
    });
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
