package com.medivault.fortress

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.security.MessageDigest

class LoginActivity : AppCompatActivity() {

    private lateinit var sp: SharedPreferences
    private lateinit var llSetupForm: LinearLayout
    private lateinit var llLoginForm: LinearLayout

    private lateinit var etSetupPass: EditText
    private lateinit var etSetupQuestion: EditText
    private lateinit var etSetupAnswer: EditText
    private lateinit var btnSetup: Button

    private lateinit var etLoginPass: EditText
    private lateinit var btnLogin: Button
    private lateinit var tvForgotPassword: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        sp = getSharedPreferences("mv_security", Context.MODE_PRIVATE)

        llSetupForm = findViewById(R.id.llSetupForm)
        llLoginForm = findViewById(R.id.llLoginForm)

        etSetupPass = findViewById(R.id.etSetupPass)
        etSetupQuestion = findViewById(R.id.etSetupQuestion)
        etSetupAnswer = findViewById(R.id.etSetupAnswer)
        btnSetup = findViewById(R.id.btnSetup)

        etLoginPass = findViewById(R.id.etLoginPass)
        btnLogin = findViewById(R.id.btnLogin)
        tvForgotPassword = findViewById(R.id.tvForgotPassword)

        val passHash = sp.getString("mv_pass_hash", null)

        if (passHash == null) {
            // Setup needed
            llSetupForm.visibility = View.VISIBLE
            llLoginForm.visibility = View.GONE
        } else {
            // Unlock required
            llSetupForm.visibility = View.GONE
            llLoginForm.visibility = View.VISIBLE
        }

        btnSetup.setOnClickListener {
            val pass = etSetupPass.text.toString().trim()
            val quest = etSetupQuestion.text.toString().trim()
            val ans = etSetupAnswer.text.toString().trim().lowercase()

            if (pass.isEmpty() || quest.isEmpty() || ans.isEmpty()) {
                Toast.makeText(this, "Please fill in all security fields.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val editor = sp.edit()
            editor.putString("mv_pass_hash", sha256(pass))
            editor.putString("mv_quest", quest)
            editor.putString("mv_ans_hash", sha256(ans))
            editor.apply()

            Toast.makeText(this, "Vault Decryption Initialized!", Toast.LENGTH_LONG).show()
            launchMain()
        }

        btnLogin.setOnClickListener {
            val inputPass = etLoginPass.text.toString().trim()
            val savedHash = sp.getString("mv_pass_hash", null)
            
            if (sha256(inputPass) == savedHash) {
                launchMain()
            } else {
                Toast.makeText(this, "INCORRECT VAULT COMPACT CODE!", Toast.LENGTH_SHORT).show()
            }
        }

        tvForgotPassword.setOnClickListener {
            val savedQuest = sp.getString("mv_quest", "Security Question")
            val savedAnsHash = sp.getString("mv_ans_hash", "")

            // Simplified recovery flow using custom dialog inputs in sequence
            val alert = android.app.AlertDialog.Builder(this)
            alert.setTitle("Account Recovery")
            alert.setMessage("Security Question: $savedQuest")

            val input = EditText(this)
            input.hint = "Your Answer"
            alert.setView(input)

            alert.setPositiveButton("Verify") { _, _ ->
                val ansInput = input.text.toString().trim().lowercase()
                if (sha256(ansInput) == savedAnsHash) {
                    // Reset pass dialog
                    val resetAlert = android.app.AlertDialog.Builder(this)
                    resetAlert.setTitle("Reset Master Code")
                    
                    val passInput = EditText(this)
                    passInput.hint = "New Master Password"
                    resetAlert.setView(passInput)

                    resetAlert.setPositiveButton("Save") { _, _ ->
                        val newPass = passInput.text.toString().trim()
                        if (newPass.isNotEmpty()) {
                            sp.edit().putString("mv_pass_hash", sha256(newPass)).apply()
                            Toast.makeText(this, "Master password updated successfully!", Toast.LENGTH_SHORT).show()
                            recreate()
                        }
                    }
                    resetAlert.show()
                } else {
                    Toast.makeText(this, "INCORRECT ANSWER!", Toast.LENGTH_SHORT).show()
                }
            }
            alert.show()
        }
    }

    private fun launchMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun sha256(base: String): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hash = digest.digest(base.toByteArray(Charsets.UTF_8))
            val hexString = StringBuilder()
            for (b in hash) {
                val hex = Integer.toHexString(0xff and b.toInt())
                if (hex.length == 1) hexString.append('0')
                hexString.append(hex)
            }
            hexString.toString()
        } catch (ex: Exception) {
            throw RuntimeException(ex)
        }
    }
}
