package com.medivault.fortress

import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONArray
import org.json.JSONObject

object NetworkUtils {

    // Pollinations Text free API call
    fun callPollinations(prompt: String): String {
        var connection: HttpURLConnection? = null
        return try {
            val encodedPrompt = URLEncoder.encode(prompt, "UTF-8")
            val url = URL("https://text.pollinations.ai/$encodedPrompt")
            connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 15000
            connection.readTimeout = 15000

            val responseCode = connection.responseCode
            if (responseCode == HttpURLConnection.HTTP_OK) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val sb = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    sb.append(line).append("\n")
                }
                reader.close()
                val result = sb.toString().trim()
                if (result.contains("<html>", ignoreCase = true) || 
                    result.contains("<!doctype", ignoreCase = true) || 
                    result.contains("<body", ignoreCase = true)) {
                    "Jarvis: Pollinations API rate limit reached (429) or Cloudflare firewall challenge triggered. Please try again in a few moments or switch to the Gemini Pro engine in Settings."
                } else {
                    result
                }
            } else if (responseCode == 429) {
                "Jarvis: Pollinations API has received too many requests (429 Rate Limit). Please switch to Gemini Pro in Settings or try again shortly."
            } else {
                "Error: Server responded with code $responseCode"
            }
        } catch (e: Exception) {
            "Network failure: ${e.message}"
        } finally {
            connection?.disconnect()
        }
    }

    // Google Gemini API call for general text queries
    fun callGeminiText(prompt: String, apiKey: String): String {
        var connection: HttpURLConnection? = null
        return try {
            val url = URL("https://generativetimini.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey")
            // Wait, standard endpoint is: generativelanguage.googleapis.com
            val realUrl = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey")
            connection = realUrl.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.connectTimeout = 20000
            connection.readTimeout = 20000
            connection.doOutput = true

            val schemaRequestStr = createGeminiTextPayload(prompt)
            val os = OutputStreamWriter(connection.outputStream)
            os.write(schemaRequestStr)
            os.flush()
            os.close()

            val responseCode = connection.responseCode
            if (responseCode == HttpURLConnection.HTTP_OK) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val sb = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    sb.append(line)
                }
                reader.close()
                parseGeminiTextResponse(sb.toString())
            } else {
                "Error: Gemini responded with code $responseCode. Verify your API Key."
            }
        } catch (e: Exception) {
            "Failure: ${e.message}"
        } finally {
            connection?.disconnect()
        }
    }

    // Google Gemini OCR schema-based analyzer
    fun callGeminiOCR(base64Data: String, mimeType: String, systemPrompt: String, apiKey: String): String {
        var connection: HttpURLConnection? = null
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey")
            connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.connectTimeout = 35000
            connection.readTimeout = 35000
            connection.doOutput = true

            // Build schema mapping instruction to ensure highly accurate "Inbuilt Excel"
            val payload = JSONObject().apply {
                val partText = JSONObject().apply { put("text", systemPrompt) }
                val partFile = JSONObject().apply {
                    val inlineData = JSONObject().apply {
                        put("mimeType", mimeType)
                        put("data", base64Data)
                    }
                    put("inlineData", inlineData)
                }

                val content = JSONObject().apply {
                    put("parts", JSONArray().put(partFile).put(partText))
                }
                put("contents", JSONArray().put(content))

                // Request strict JSON response with schema configuration mapping
                val generationConfig = JSONObject().apply {
                    put("responseMimeType", "application/json")
                }
                put("generationConfig", generationConfig)
            }

            val os = OutputStreamWriter(connection.outputStream)
            os.write(payload.toString())
            os.flush()
            os.close()

            val responseCode = connection.responseCode
            if (responseCode == HttpURLConnection.HTTP_OK) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val sb = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    sb.append(line)
                }
                reader.close()
                parseGeminiTextResponse(sb.toString())
            } else {
                "Error: Server responded with code $responseCode"
            }
        } catch (e: Exception) {
            "OCR Call Error: ${e.message}"
        } finally {
            connection?.disconnect()
        }
    }

    private fun createGeminiTextPayload(prompt: String): String {
        return JSONObject().apply {
            val content = JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().apply { put("text", prompt) }))
            }
            put("contents", JSONArray().put(content))
        }.toString()
    }

    private fun parseGeminiTextResponse(jsonStr: String): String {
        return try {
            val obj = JSONObject(jsonStr)
            val candidates = obj.getJSONArray("candidates")
            val content = candidates.getJSONObject(0).getJSONObject("content")
            val parts = content.getJSONArray("parts")
            parts.getJSONObject(0).getString("text")
        } catch (e: Exception) {
            jsonStr // Fallback if parsing fails
        }
    }

    // Call local Ollama API
    fun callOllama(prompt: String, host: String, model: String): String {
        var connection: HttpURLConnection? = null
        return try {
            val cleanHost = host.trim().removeSuffix("/")
            val url = URL("$cleanHost/api/generate")
            connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.connectTimeout = 15000
            connection.readTimeout = 15000
            connection.doOutput = true

            val payload = JSONObject().apply {
                put("model", model)
                put("prompt", prompt)
                put("stream", false)
            }

            val os = OutputStreamWriter(connection.outputStream)
            os.write(payload.toString())
            os.flush()
            os.close()

            val responseCode = connection.responseCode
            if (responseCode == HttpURLConnection.HTTP_OK) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val sb = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    sb.append(line)
                }
                reader.close()
                val responseObj = JSONObject(sb.toString())
                responseObj.optString("response", "No response content from Ollama")
            } else {
                "Error: Ollama responded with code $responseCode"
            }
        } catch (e: Exception) {
            "Ollama connection failure: ${e.message}\nPlease verify Ollama is running and accessible at $host"
        } finally {
            connection?.disconnect()
        }
    }

    // List models from local Ollama API
    fun getOllamaModels(host: String): List<String> {
        var connection: HttpURLConnection? = null
        val modelsList = ArrayList<String>()
        try {
            val cleanHost = host.trim().removeSuffix("/")
            val url = URL("$cleanHost/api/tags")
            connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 8000
            connection.readTimeout = 8000

            val responseCode = connection.responseCode
            if (responseCode == HttpURLConnection.HTTP_OK) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val sb = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    sb.append(line)
                }
                reader.close()
                val responseObj = JSONObject(sb.toString())
                val modelsArray = responseObj.optJSONArray("models")
                if (modelsArray != null) {
                    for (i in 0 until modelsArray.length()) {
                        val modelItem = modelsArray.getJSONObject(i)
                        val name = modelItem.optString("name", "")
                        if (name.isNotEmpty()) {
                            modelsList.add(name)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // Empty list on failure
        } finally {
            connection?.disconnect()
        }
        return modelsList
    }

    // Call OpenAI / OpenRouter API
    fun callOpenAICompatible(prompt: String, apiKey: String, baseUrl: String, model: String): String {
        var connection: HttpURLConnection? = null
        return try {
            val cleanHost = baseUrl.trim().removeSuffix("/")
            val url = URL("$cleanHost/chat/completions")
            connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("Authorization", "Bearer $apiKey")
            connection.connectTimeout = 15000
            connection.readTimeout = 15000
            connection.doOutput = true

            val messages = JSONArray()
            messages.put(JSONObject().apply {
                put("role", "user")
                put("content", prompt)
            })

            val payload = JSONObject().apply {
                put("model", model)
                put("messages", messages)
            }

            val os = OutputStreamWriter(connection.outputStream)
            os.write(payload.toString())
            os.flush()
            os.close()

            val responseCode = connection.responseCode
            if (responseCode in 200..299) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val sb = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    sb.append(line)
                }
                reader.close()
                val responseObj = JSONObject(sb.toString())
                val choices = responseObj.optJSONArray("choices")
                if (choices != null && choices.length() > 0) {
                    choices.getJSONObject(0).optJSONObject("message")?.optString("content", "Empty") ?: "Parse error"
                } else {
                    "No valid choices returned."
                }
            } else {
                "Error: Server responded with code $responseCode"
            }
        } catch (e: Exception) {
            "API connection failure: ${e.message}\nPlease verify Base URL and API Key."
        } finally {
            connection?.disconnect()
        }
    }

    // List models from OpenAI / OpenRouter API
    fun getOpenAIModels(apiKey: String, baseUrl: String): List<String> {
        var connection: HttpURLConnection? = null
        val modelsList = ArrayList<String>()
        try {
            val cleanHost = baseUrl.trim().removeSuffix("/")
            val url = URL("$cleanHost/models")
            connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.setRequestProperty("Authorization", "Bearer $apiKey")
            connection.connectTimeout = 8000
            connection.readTimeout = 8000

            val responseCode = connection.responseCode
            if (responseCode in 200..299) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val sb = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    sb.append(line)
                }
                reader.close()
                val responseObj = JSONObject(sb.toString())
                val dataArray = responseObj.optJSONArray("data")
                if (dataArray != null) {
                    for (i in 0 until dataArray.length()) {
                        val modelItem = dataArray.getJSONObject(i)
                        val id = modelItem.optString("id", "")
                        if (id.isNotEmpty()) {
                            modelsList.add(id)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // Empty list on failure
        } finally {
            connection?.disconnect()
        }
        return modelsList
    }
}
