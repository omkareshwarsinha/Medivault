package com.medivault.fortress

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var db: DatabaseHelper
    private lateinit var sp: SharedPreferences
    private lateinit var tts: TextToSpeech

    private var activePage = 0
    private lateinit var viewFlipper: ViewFlipper

    // Navigation indicators
    private lateinit var navHome: LinearLayout
    private lateinit var navVault: LinearLayout
    private lateinit var navMeds: LinearLayout
    private lateinit var navHealth: LinearLayout
    private lateinit var navChat: LinearLayout
    private lateinit var navSettings: LinearLayout

    private lateinit var ivNavHome: ImageView
    private lateinit var ivNavVault: ImageView
    private lateinit var ivNavMeds: ImageView
    private lateinit var ivNavHealth: ImageView
    private lateinit var ivNavChat: ImageView
    private lateinit var ivNavSettings: ImageView

    private lateinit var tvNavHome: TextView
    private lateinit var tvNavVault: TextView
    private lateinit var tvNavMeds: TextView
    private lateinit var tvNavHealth: TextView
    private lateinit var tvNavChat: TextView
    private lateinit var tvNavSettings: TextView

    // Tab 0: Home widgets
    private lateinit var tvTotalSpends: TextView
    private lateinit var tvVaultCount: TextView
    private lateinit var btnScanDocument: Button
    private lateinit var llScanLoading: LinearLayout
    private lateinit var rvRecentHome: RecyclerView
    private lateinit var btnBackupAllHome: Button

    // Tab 1: Vault widgets
    private lateinit var rvVaultFull: RecyclerView

    // Tab 2: Med Cabinet widgets
    private lateinit var rvMedicines: RecyclerView
    private lateinit var btnAddMedicine: Button

    // Tab 3: Health Suite widgets
    private lateinit var etBmiWeight: EditText
    private lateinit var etBmiHeight: EditText
    private lateinit var btnCalcBmi: Button
    private lateinit var tvBmiResult: TextView
    private lateinit var btnSymptomGo: Button
    private lateinit var llGraphContainer: LinearLayout

    // Tab 4: Chat Assistant widgets
    private lateinit var rvChatHistory: RecyclerView
    private lateinit var pbChatLoading: ProgressBar
    private lateinit var btnMicDictate: ImageButton
    private lateinit var etChatQuery: EditText
    private lateinit var btnSendMessage: ImageButton
    private val chatList = ArrayList<ChatMessage>()

    // Tab 5: Settings widgets
    private lateinit var rgAiEngine: RadioGroup
    private lateinit var rbGemini: RadioButton
    private lateinit var rbPollinations: RadioButton
    private lateinit var rbOllama: RadioButton
    private lateinit var rbOpenAI: RadioButton
    private lateinit var rbOpenRouter: RadioButton
    private lateinit var etApiKey: EditText
    private lateinit var llConfigSection: LinearLayout
    private lateinit var etHost: EditText
    private lateinit var etModel: EditText
    private lateinit var btnTestConnection: Button
    private lateinit var tvModelsList: TextView
    private lateinit var scExpiryAlerts: SwitchCompat
    private lateinit var btnClearVault: Button
    private lateinit var btnResetPass: Button

    // Request Pickers
    private val PICK_DOCUMENT_REQUEST = 120
    private val SPEECH_INPUT_REQUEST = 130

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = DatabaseHelper(this)
        sp = getSharedPreferences("mv_security", Context.MODE_PRIVATE)
        tts = TextToSpeech(this, this)

        initViews()
        setupBottomNav()
        setupHomeView()
        setupVaultView()
        setupCabinetView()
        setupHealthSuiteView()
        setupChatAssistantView()
        setupSettingsView()

        scheduleDailyExpiryAlerts()
    }

    private fun initViews() {
        viewFlipper = findViewById(R.id.viewFlipper)

        navHome = findViewById(R.id.nav_home)
        navVault = findViewById(R.id.nav_vault)
        navMeds = findViewById(R.id.nav_meds)
        navHealth = findViewById(R.id.nav_health)
        navChat = findViewById(R.id.nav_chat)
        navSettings = findViewById(R.id.nav_settings)

        ivNavHome = findViewById(R.id.iv_nav_home)
        ivNavVault = findViewById(R.id.iv_nav_vault)
        ivNavMeds = findViewById(R.id.iv_nav_meds)
        ivNavHealth = findViewById(R.id.iv_nav_health)
        ivNavChat = findViewById(R.id.iv_nav_chat)
        ivNavSettings = findViewById(R.id.iv_nav_settings)

        tvNavHome = findViewById(R.id.tv_nav_home)
        tvNavVault = findViewById(R.id.tv_nav_vault)
        tvNavMeds = findViewById(R.id.tv_nav_meds)
        tvNavHealth = findViewById(R.id.tv_nav_health)
        tvNavChat = findViewById(R.id.tv_nav_chat)
        tvNavSettings = findViewById(R.id.tv_nav_settings)

        val btnLogout: ImageButton = findViewById(R.id.btnLogout)
        btnLogout.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    private fun setupBottomNav() {
        val clickListener = View.OnClickListener { v ->
            when (v.id) {
                R.id.nav_home -> switchTab(0)
                R.id.nav_vault -> switchTab(1)
                R.id.nav_meds -> switchTab(2)
                R.id.nav_health -> switchTab(3)
                R.id.nav_chat -> switchTab(4)
                R.id.nav_settings -> switchTab(5)
            }
        }
        navHome.setOnClickListener(clickListener)
        navVault.setOnClickListener(clickListener)
        navMeds.setOnClickListener(clickListener)
        navHealth.setOnClickListener(clickListener)
        navChat.setOnClickListener(clickListener)
        navSettings.setOnClickListener(clickListener)
    }

    private fun switchTab(tabIndex: Int) {
        if (activePage == tabIndex) return
        activePage = tabIndex
        viewFlipper.displayedChild = tabIndex

        val gray = ContextCompat.getColor(this, R.color.text_gray)
        val emerald = ContextCompat.getColor(this, R.color.primary)

        // Reset all
        ivNavHome.imageTintList = ColorStateList.valueOf(gray)
        ivNavVault.imageTintList = ColorStateList.valueOf(gray)
        ivNavMeds.imageTintList = ColorStateList.valueOf(gray)
        ivNavHealth.imageTintList = ColorStateList.valueOf(gray)
        ivNavChat.imageTintList = ColorStateList.valueOf(gray)
        ivNavSettings.imageTintList = ColorStateList.valueOf(gray)

        tvNavHome.setTextColor(gray)
        tvNavVault.setTextColor(gray)
        tvNavMeds.setTextColor(gray)
        tvNavHealth.setTextColor(gray)
        tvNavChat.setTextColor(gray)
        tvNavSettings.setTextColor(gray)

        // Select targeted
        when (tabIndex) {
            0 -> {
                ivNavHome.imageTintList = ColorStateList.valueOf(emerald)
                tvNavHome.setTextColor(emerald)
                refreshHomeStats()
            }
            1 -> {
                ivNavVault.imageTintList = ColorStateList.valueOf(emerald)
                tvNavVault.setTextColor(emerald)
                refreshVaultHistory()
            }
            2 -> {
                ivNavMeds.imageTintList = ColorStateList.valueOf(emerald)
                tvNavMeds.setTextColor(emerald)
                refreshMedsList()
            }
            3 -> {
                ivNavHealth.imageTintList = ColorStateList.valueOf(emerald)
                tvNavHealth.setTextColor(emerald)
                refreshTrendsChart()
            }
            4 -> {
                ivNavChat.imageTintList = ColorStateList.valueOf(emerald)
                tvNavChat.setTextColor(emerald)
            }
            5 -> {
                ivNavSettings.imageTintList = ColorStateList.valueOf(emerald)
                tvNavSettings.setTextColor(emerald)
            }
        }
    }

    // TAB 0: HOME IMPLEMENTATION
    private fun setupHomeView() {
        tvTotalSpends = findViewById(R.id.tvTotalSpends)
        tvVaultCount = findViewById(R.id.tvVaultCount)
        btnScanDocument = findViewById(R.id.btnScanDocument)
        llScanLoading = findViewById(R.id.llScanLoading)
        rvRecentHome = findViewById(R.id.rvRecentHome)
        btnBackupAllHome = findViewById(R.id.btnBackupAllHome)

        btnScanDocument.setOnClickListener {
            // Trigger storage selection direct to support text files, image files, or PDF files.
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "*/*"
                val extraMimeTypes = arrayOf("image/*", "application/pdf", "text/plain")
                putExtra(Intent.EXTRA_MIME_TYPES, extraMimeTypes)
            }
            startActivityForResult(Intent.createChooser(intent, "Choose Document / Med Bill"), PICK_DOCUMENT_REQUEST)
        }

        btnBackupAllHome.setOnClickListener {
            // Write a simple plaintext backup data package
            val scans = db.getAllScans()
            if (scans.isEmpty()) {
                Toast.makeText(this, "Vault is empty. No files to export.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val reportBuilder = StringBuilder().append("--- MediVault Fortress Local Export ---\n\n")
            for (s in scans) {
                reportBuilder.append("Facility: ${s.hospitalName}\n")
                reportBuilder.append("Date: ${s.date}\n")
                reportBuilder.append("Total: ₹${s.totalAmount}\n")
                reportBuilder.append("Summary (Hindi): ${s.summaryHindi}\n\n")
            }
            // Trigger native share of this backup package
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, reportBuilder.toString())
            }
            startActivity(Intent.createChooser(shareIntent, "Save Backup Summary"))
        }

        rvRecentHome.layoutManager = LinearLayoutManager(this)
        refreshHomeStats()
    }

    private fun refreshHomeStats() {
        val scans = db.getAllScans()
        val totalSpends = scans.sumOf { it.totalAmount }
        tvTotalSpends.text = "₹${String.format("%,.1f", totalSpends)}"
        tvVaultCount.text = scans.size.toString()

        rvRecentHome.adapter = ScanAdapter(this, scans.take(4)) { scanItem ->
            showScanDetailsDialog(scanItem)
        }
    }

    // TAB 1: VAULT INDEX
    private fun setupVaultView() {
        rvVaultFull = findViewById(R.id.rvVaultFull)
        rvVaultFull.layoutManager = LinearLayoutManager(this)
    }

    private fun refreshVaultHistory() {
        val scans = db.getAllScans()
        rvVaultFull.adapter = ScanAdapter(this, scans) { scanItem ->
            showScanDetailsDialog(scanItem)
        }
    }

    // TAB 2: MEDICINE CABINET
    private fun setupCabinetView() {
        rvMedicines = findViewById(R.id.rvMedicines)
        btnAddMedicine = findViewById(R.id.btnAddMedicine)

        rvMedicines.layoutManager = LinearLayoutManager(this)

        btnAddMedicine.setOnClickListener {
            val alert = android.app.AlertDialog.Builder(this)
            alert.setTitle("Add Medication")

            val layout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                padding = 40
            }

            val etName = EditText(this).apply { hint = "Medicine Name" }
            val etExp = EditText(this).apply { hint = "Expiry (YYYY-MM-DD)" }

            layout.addView(etName)
            layout.addView(etExp)
            alert.setView(layout)

            alert.setPositiveButton("Track") { _, _ ->
                val name = etName.text.toString().trim()
                val exp = etExp.text.toString().trim()
                if (name.isNotEmpty() && exp.isNotEmpty()) {
                    db.insertMedicine(name, exp)
                    Toast.makeText(this, "$name added to active logs.", Toast.LENGTH_SHORT).show()
                    refreshMedsList()
                } else {
                    Toast.makeText(this, "Fail: Name & Date required.", Toast.LENGTH_SHORT).show()
                }
            }
            alert.show()
        }
        refreshMedsList()
    }

    private fun refreshMedsList() {
        val meds = db.getAllMedicines()
        rvMedicines.adapter = MedsAdapter(this, meds) { id ->
            db.deleteMed(id)
            refreshMedsList()
        }
    }

    // TAB 3: HEALTH SUITE
    private fun setupHealthSuiteView() {
        etBmiWeight = findViewById(R.id.etBmiWeight)
        etBmiHeight = findViewById(R.id.etBmiHeight)
        btnCalcBmi = findViewById(R.id.btnCalcBmi)
        tvBmiResult = findViewById(R.id.tvBmiResult)
        btnSymptomGo = findViewById(R.id.btnSymptomGo)
        llGraphContainer = findViewById(R.id.llGraphContainer)

        btnCalcBmi.setOnClickListener {
            val weightStr = etBmiWeight.text.toString().trim()
            val heightStr = etBmiHeight.text.toString().trim()

            if (weightStr.isEmpty() || heightStr.isEmpty()) {
                Toast.makeText(this, "Enter values first.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val weight = weightStr.toDouble()
            val height = heightStr.toDouble() / 100 // cm to meters
            val bmi = weight / (height * height)

            val status = when {
                bmi < 18.5 -> "Underweight"
                bmi < 24.9 -> "Normal weight"
                bmi < 29.9 -> "Overweight"
                else -> "Obese"
            }

            tvBmiResult.text = "Your BMI: ${String.format("%.1f", bmi)} ($status)"
            tvBmiResult.visibility = View.VISIBLE
        }

        btnSymptomGo.setOnClickListener {
            // Trigger redirection directly to active speech console console!
            switchTab(4)
            etChatQuery.setText("I am feeling a bit sick. Please initiate smart symptom checker triage diagnostics.")
        }
        refreshTrendsChart()
    }

    private fun refreshTrendsChart() {
        llGraphContainer.removeAllViews()
        val scans = db.getAllScans().take(8).reversed()
        if (scans.isEmpty()) {
            val tv = TextView(this).apply {
                text = "No records to trend."
                textColor = Color.GRAY
            }
            llGraphContainer.addView(tv)
            return
        }

        val maxAmount = scans.maxOfOrNull { it.totalAmount } ?: 1.0

        for (s in scans) {
            val barLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = android.view.Gravity.CENTER_HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1.0f)
            }

            // Calculate heights scaling
            val heightRatio = (s.totalAmount / maxAmount).coerceIn(0.1, 1.0)
            val barView = View(this).apply {
                val pHeight = (100 * heightRatio).toInt()
                layoutParams = LinearLayout.LayoutParams(24, pHeight).apply {
                    bottomMargin = 8
                }
                background = ContextCompat.getDrawable(this@MainActivity, R.drawable.cyber_bar) ?: ColorDrawable(Color.GREEN)
            }

            val label = TextView(this).apply {
                text = s.hospitalName.take(3).uppercase()
                textSize = 9sp
                textColor = Color.GRAY
            }

            barLayout.addView(barView)
            barLayout.addView(label)
            llGraphContainer.addView(barLayout)
        }
    }

    // TAB 4: CHAT CONSOLE
    private fun setupChatAssistantView() {
        rvChatHistory = findViewById(R.id.rvChatHistory)
        pbChatLoading = findViewById(R.id.pbChatLoading)
        btnMicDictate = findViewById(R.id.btnMicDictate)
        etChatQuery = findViewById(R.id.etChatQuery)
        btnSendMessage = findViewById(R.id.btnSendMessage)

        rvChatHistory.layoutManager = LinearLayoutManager(this)
        rvChatHistory.adapter = ChatAdapter(chatList)

        // Preload welcoming state
        chatList.add(ChatMessage(0, "AI", "MediVault Fortress initialized. Ask me anything about files or health data!"))

        btnSendMessage.setOnClickListener {
            val q = etChatQuery.text.toString().trim()
            if (q.isNotEmpty()) submitChat(q)
        }

        btnMicDictate.setOnClickListener {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN") // Hinglish compliant triggers
            }
            try {
                startActivityForResult(intent, SPEECH_INPUT_REQUEST)
            } catch (e: Exception) {
                Toast.makeText(this, "Speech diagnostics error.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun submitChat(queryText: String) {
        val userItem = ChatMessage(System.currentTimeMillis(), "USER", queryText)
        chatList.add(userItem)
        rvChatHistory.adapter?.notifyItemInserted(chatList.size - 1)
        rvChatHistory.scrollToPosition(chatList.size - 1)
        etChatQuery.setText("")

        // Check 1000+ Predefined Commands first (Offline execution)
        val predefinedMatch = PredefinedCommands.matchCommand(queryText)
        if (predefinedMatch != null) {
            val cleanedResponse = handleActionIfPresent(predefinedMatch)
            chatList.add(ChatMessage(System.currentTimeMillis(), "AI", cleanedResponse))
            rvChatHistory.adapter?.notifyItemInserted(chatList.size - 1)
            rvChatHistory.scrollToPosition(chatList.size - 1)
            speakHindi(cleanedResponse)
            return
        }

        pbChatLoading.visibility = View.VISIBLE

        val engine = sp.getString("ai_engine_setting", "pollinations")
        val key = etApiKey.text.toString().trim()
        val host = etHost.text.toString().trim()
        val model = etModel.text.toString().trim()

        executor.execute {
            val contextScans = db.getAllScans()
            val systemSystemPrompt = "You are Jarvis, a secure highly optimized Android 9 AI voice assistant. " +
                    "Your response tags can control the app: [ACTION: PLAY_SONG, PARAM: \"song_name\"] or " +
                    "[ACTION: DIAL_NUMBER, PARAM: \"phone_number\"]. " +
                    "Context scans stored: $contextScans. " +
                    "User query: $queryText. Answer in clear natural Hinglish/Hindi or English."

            val aiResponse = when (engine) {
                "gemini" -> {
                    if (key.isEmpty()) {
                        "Error: Gemini requires a configuration API Key in the Settings panel."
                    } else {
                        NetworkUtils.callGeminiText(systemSystemPrompt, key)
                    }
                }
                "ollama" -> {
                    NetworkUtils.callOllama(systemSystemPrompt, host, model)
                }
                "openai", "openrouter" -> {
                    if (key.isEmpty()) {
                        "Error: Configuration API Key is required in Settings."
                    } else {
                        NetworkUtils.callOpenAICompatible(systemSystemPrompt, key, host, model)
                    }
                }
                else -> {
                    NetworkUtils.callPollinations(systemSystemPrompt)
                }
            }

            mainHandler.post {
                pbChatLoading.visibility = View.GONE
                val cleanedResponse = handleActionIfPresent(aiResponse)
                chatList.add(ChatMessage(System.currentTimeMillis(), "AI", cleanedResponse))
                rvChatHistory.adapter?.notifyItemInserted(chatList.size - 1)
                rvChatHistory.scrollToPosition(chatList.size - 1)

                // TTS audio playback speaker
                speakHindi(cleanedResponse)
            }
        }
    }

    private fun handleActionIfPresent(rawResponse: String): String {
        var cleanResponse = rawResponse
        try {
            val pattern = Regex("\\[ACTION:\\s*(\\w+),\\s*PARAM:\\s*\"([^\"]*)\"\\]")
            val match = pattern.find(rawResponse)
            if (match != null) {
                val actionType = match.groupValues[1]
                val actionParam = match.groupValues[2]
                cleanResponse = rawResponse.replace(match.value, "").trim()
                
                mainHandler.post {
                    executeVoiceAction(actionType, actionParam)
                }
            }
        } catch (e: Exception) {
            // Unhandled parsing issues
        }
        return if (cleanResponse.isEmpty()) "Action executing..." else cleanResponse
    }

    private fun executeVoiceAction(actionType: String, param: String) {
        when (actionType.uppercase(Locale.getDefault())) {
            "PLAY_SONG" -> {
                try {
                    Toast.makeText(this, "Playing song: $param", Toast.LENGTH_SHORT).show()
                    val intent = Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                    intent.putExtra(android.provider.MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                    intent.putExtra(android.app.SearchManager.QUERY, param)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    if (intent.resolveActivity(packageManager) != null) {
                        startActivity(intent)
                    } else {
                        // Fallback to youtube search
                        val fallback = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + java.net.URLEncoder.encode(param, "UTF-8")))
                        fallback.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        startActivity(fallback)
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Failed to play song: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
            "DIAL_NUMBER" -> {
                try {
                    Toast.makeText(this, "Dialing number: $param", Toast.LENGTH_SHORT).show()
                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$param"))
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(this, "Failed to open dialer: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
            "SEND_SMS" -> {
                try {
                    val parts = param.split("|")
                    val number = parts.getOrNull(0) ?: ""
                    val body = parts.getOrNull(1) ?: ""
                    Toast.makeText(this, "Sending message to $number", Toast.LENGTH_SHORT).show()
                    val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number"))
                    intent.putExtra("sms_body", body)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(this, "Failed to send message: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
            "SHOW_TAB" -> {
                val tabIdx = when (param.lowercase(Locale.getDefault())) {
                    "home" -> 0
                    "vault" -> 1
                    "meds" -> 2
                    "health" -> 3
                    "chat" -> 4
                    "settings" -> 5
                    else -> -1
                }
                if (tabIdx != -1) {
                    switchTab(tabIdx)
                }
            }
        }
    }

    private fun speakHindi(text: String) {
        val cleanSpeech = text.replace(Regex("[^\\w\\s,.]"), "") // Sanitized strings
        tts.speak(cleanSpeech, TextToSpeech.QUEUE_FLUSH, null, "HINDI_TTS_ID")
    }

    // TAB 5: SETTINGS PANELS
    private fun setupSettingsView() {
        rgAiEngine = findViewById(R.id.rgAiEngine)
        rbGemini = findViewById(R.id.rbGemini)
        rbPollinations = findViewById(R.id.rbPollinations)
        rbOllama = findViewById(R.id.rbOllama)
        rbOpenAI = findViewById(R.id.rbOpenAI)
        rbOpenRouter = findViewById(R.id.rbOpenRouter)
        llConfigSection = findViewById(R.id.llConfigSection)
        etApiKey = findViewById(R.id.etApiKey)
        etHost = findViewById(R.id.etHost)
        etModel = findViewById(R.id.etModel)
        btnTestConnection = findViewById(R.id.btnTestConnection)
        tvModelsList = findViewById(R.id.tvModelsList)
        
        scExpiryAlerts = findViewById(R.id.scExpiryAlerts)
        btnClearVault = findViewById(R.id.btnClearVault)
        btnResetPass = findViewById(R.id.btnResetPass)

        val savedEngine = sp.getString("ai_engine_setting", "pollinations")
        val savedKey = sp.getString("gemini_api_key", "")
        val savedHost = sp.getString("ollama_host", "http://10.0.2.2:11434")
        val savedModel = sp.getString("ollama_model", "llama3")

        etApiKey.setText(savedKey)
        etHost.setText(savedHost)
        etModel.setText(savedModel)

        when (savedEngine) {
            "gemini" -> {
                rbGemini.isChecked = true
                etApiKey.visibility = View.VISIBLE
                etHost.visibility = View.GONE
                btnTestConnection.visibility = View.GONE
                tvModelsList.visibility = View.GONE
                llConfigSection.visibility = View.VISIBLE
            }
            "ollama" -> {
                rbOllama.isChecked = true
                etApiKey.visibility = View.GONE
                etHost.visibility = View.VISIBLE
                btnTestConnection.visibility = View.VISIBLE
                tvModelsList.visibility = View.VISIBLE
                llConfigSection.visibility = View.VISIBLE
            }
            "openai", "openrouter" -> {
                if (savedEngine == "openai") rbOpenAI.isChecked = true else rbOpenRouter.isChecked = true
                etApiKey.visibility = View.VISIBLE
                etHost.visibility = View.VISIBLE
                btnTestConnection.visibility = View.GONE
                tvModelsList.visibility = View.GONE
                llConfigSection.visibility = View.VISIBLE
            }
            else -> {
                rbPollinations.isChecked = true
                llConfigSection.visibility = View.GONE
            }
        }

        rgAiEngine.setOnCheckedChangeListener { _, checkedId ->
            val active = when (checkedId) {
                R.id.rbGemini -> "gemini"
                R.id.rbOllama -> "ollama"
                R.id.rbOpenAI -> "openai"
                R.id.rbOpenRouter -> "openrouter"
                else -> "pollinations"
            }
            sp.edit().putString("ai_engine_setting", active).apply()
            
            if (active == "gemini") {
                etApiKey.visibility = View.VISIBLE
                etHost.visibility = View.GONE
                btnTestConnection.visibility = View.GONE
                tvModelsList.visibility = View.GONE
                llConfigSection.visibility = View.VISIBLE
            } else if (active == "ollama") {
                etApiKey.visibility = View.GONE
                etHost.visibility = View.VISIBLE
                btnTestConnection.visibility = View.VISIBLE
                tvModelsList.visibility = View.VISIBLE
                llConfigSection.visibility = View.VISIBLE
                if(etHost.text.isEmpty()) etHost.setText("http://10.0.2.2:11434")
            } else if (active == "openai" || active == "openrouter") {
                etApiKey.visibility = View.VISIBLE
                etHost.visibility = View.VISIBLE
                btnTestConnection.visibility = View.GONE
                tvModelsList.visibility = View.GONE
                llConfigSection.visibility = View.VISIBLE
                if (active == "openai" && (etHost.text.isEmpty() || etHost.text.contains("10.0"))) {
                    etHost.setText("https://api.openai.com/v1")
                } else if (active == "openrouter" && (etHost.text.isEmpty() || etHost.text.contains("10.0"))) {
                    etHost.setText("https://openrouter.ai/api/v1")
                }
            } else {
                llConfigSection.visibility = View.GONE
            }
        }

        etApiKey.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                sp.edit().putString("gemini_api_key", etApiKey.text.toString().trim()).apply()
            }
        }

        etHost.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                sp.edit().putString("ollama_host", etHost.text.toString().trim()).apply()
            }
        }

        etModel.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                sp.edit().putString("ollama_model", etModel.text.toString().trim()).apply()
            }
        }

        btnTestConnection.setOnClickListener {
            val host = etHost.text.toString().trim()
            val active = sp.getString("ai_engine_setting", "pollinations")
            val apiKey = etApiKey.text.toString().trim()
            
            tvModelsList.text = "Querying local API server..."
            executor.execute {
                val list = if (active == "ollama") {
                    NetworkUtils.getOllamaModels(host)
                } else {
                    NetworkUtils.getOpenAIModels(apiKey, host)
                }
                mainHandler.post {
                    if (list.isNotEmpty()) {
                        tvModelsList.text = "Connected! Successfully retrieved models:\n" + list.joinToString("\n• ", prefix = "• ")
                        Toast.makeText(this, "Connection check succeeded!", Toast.LENGTH_SHORT).show()
                    } else {
                        tvModelsList.text = "Failed to connect or fetch models from API instance."
                        Toast.makeText(this, "Connection check failed.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        btnClearVault.setOnClickListener {
            android.app.AlertDialog.Builder(this)
                .setTitle("Purge Database")
                .setMessage("Are you absolutely sure you want to clear your local database files? There are no cloud backups.")
                .setPositiveButton("Purge") { _, _ ->
                    db.deleteAllScans()
                    Toast.makeText(this, "Local Database cleared.", Toast.LENGTH_SHORT).show()
                    loadVaultData()
                    refreshHomeStats()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        findViewById<Button>(R.id.btnClearChat).setOnClickListener {
            chatList.clear()
            chatList.add(ChatMessage(System.currentTimeMillis(), "AI", "Terminal chat instance reset. All local session data wiped."))
            rvChatHistory.adapter?.notifyDataSetChanged()
            Toast.makeText(this, "Chat Wiped", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnClearAllData).setOnClickListener {
            android.app.AlertDialog.Builder(this)
                .setTitle("FACTORY RESET")
                .setMessage("This will erase ALL scans, medicines, and chats.")
                .setPositiveButton("Purge All") { _, _ ->
                    db.deleteAllScans()
                    executor.execute {
                        val medsList = db.getAllMedicines()
                        medsList.forEach { db.deleteMed(it.id) }
                        mainHandler.post {
                            loadVaultData()
                            loadMeds()
                            refreshHomeStats()
                            chatList.clear()
                            rvChatHistory.adapter?.notifyDataSetChanged()
                            Toast.makeText(this, "All local data has been exterminated.", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        btnResetPass.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    // RESULTS PROCESSOR CALLS (FILE PICKS / SPEECH DETECTION)
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode != RESULT_OK || data == null) return

        when (requestCode) {
            PICK_DOCUMENT_REQUEST -> {
                val fileUri = data.data ?: return
                processScannedFile(fileUri)
            }
            SPEECH_INPUT_REQUEST -> {
                val speechResult = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                if (!speechResult.isNullOrEmpty()) {
                    etChatQuery.setText(speechResult[0])
                }
            }
        }
    }

    private fun processScannedFile(uri: Uri) {
        llScanLoading.visibility = View.VISIBLE
        executor.execute {
            try {
                val cResolver = contentResolver
                val mType = cResolver.getType(uri) ?: "image/jpeg"
                
                var bytesData: ByteArray? = null
                val iStream: InputStream? = cResolver.openInputStream(uri)
                if (iStream != null) {
                    bytesData = iStream.readBytes()
                    iStream.close()
                }

                if (bytesData == null) {
                    mainHandler.post { 
                        llScanLoading.visibility = View.GONE
                        Toast.makeText(this, "Failed to read document stream.", Toast.LENGTH_SHORT).show()
                    }
                    return@execute
                }

                val base64Encoded = Base64.encodeToString(bytesData, Base64.DEFAULT)
                val gemApiKey = sp.getString("gemini_api_key", "") ?: ""

                if (gemApiKey.isEmpty()) {
                    mainHandler.post {
                        llScanLoading.visibility = View.GONE
                        Toast.makeText(this, "Configuration failure: Setup your Gemini key in the Settings tab.", Toast.LENGTH_LONG).show()
                    }
                    return@execute
                }

                val systemPrompt = "Analyze this medical invoice. Expose everything in valid JSON obeying this schema structure: {\"documentType\":\"INVOICE\",\"fields\":{\"hospitalName\":\"Extract Hospital name detail\",\"date\":\"YYYY-MM-DD\",\"totalAmount\":1.0,\"items\":[{\"name\":\"mName\",\"qty\":1,\"mrp\":1.0,\"rate\":1.0,\"total\":1.0}],\"allLines\":[{\"originalText\":\"raw element text\",\"interpretedCategory\":\"CATEGORY\"}]},\"fullRawText\":\"Full raw text mapping\",\"summaryHindi\":\"Hindi prescription synthesis\"}"

                val ocrResponseJSON = NetworkUtils.callGeminiOCR(base64Encoded, mType, systemPrompt, gemApiKey)

                mainHandler.post {
                    llScanLoading.visibility = View.GONE
                    try {
                        val obj = JSONObject(ocrResponseJSON)
                        val docType = obj.getString("documentType")
                        val fields = obj.getJSONObject("fields")
                        val hosp = fields.getString("hospitalName")
                        val dVal = fields.getString("date")
                        val total = fields.getDouble("totalAmount")
                        
                        val items = fields.getJSONArray("items").toString()
                        val allLines = fields.getJSONArray("allLines").toString()
                        
                        val rawText = obj.getString("fullRawText")
                        val hindiSum = obj.getString("summaryHindi")

                        db.insertScan(dVal, hosp, total, docType, hindiSum, rawText, items, allLines)
                        Toast.makeText(this@MainActivity, "Invoice Processed Successfully!", Toast.LENGTH_SHORT).show()
                        
                        refreshHomeStats()
                        speakHindi(hindiSum)
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "Data Mapping Exception: Verify document resolution.", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                mainHandler.post {
                    llScanLoading.visibility = View.GONE
                    Toast.makeText(this@MainActivity, "System Exception: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // MODAL POPUPS DETAIL INBUILT EXCEL ENGINE
    private fun showScanDetailsDialog(scan: ScanItem) {
        val dialog = android.app.Dialog(this)
        dialog.setContentView(R.layout.dialog_vault_detail)
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val tvDetailHospital: TextView = dialog.findViewById(R.id.tvDetailHospital)
        val tvDetailTotal: TextView = dialog.findViewById(R.id.tvDetailTotal)
        val tvDetailDate: TextView = dialog.findViewById(R.id.tvDetailDate)
        val tvDetailHindiSummary: TextView = dialog.findViewById(R.id.tvDetailHindiSummary)
        val tvDetailRawText: TextView = dialog.findViewById(R.id.tvDetailRawText)
        val btnDetailSpeak: Button = dialog.findViewById(R.id.btnDetailSpeak)
        val btnDetailClose: ImageButton = dialog.findViewById(R.id.btnDetailClose)

        val btnDetailShare: Button = dialog.findViewById(R.id.btnDetailShare)
        val btnDetailDownload: Button = dialog.findViewById(R.id.btnDetailDownload)

        val llSheetItemsContainer: LinearLayout = dialog.findViewById(R.id.llSheetItemsContainer)
        val llAllLinesContainer: LinearLayout = dialog.findViewById(R.id.llAllLinesContainer)

        tvDetailHospital.text = scan.hospitalName
        tvDetailTotal.text = "₹${scan.totalAmount}"
        tvDetailDate.text = "Date: ${scan.date}"
        tvDetailHindiSummary.text = scan.summaryHindi
        tvDetailRawText.text = scan.fullRawText

        btnDetailClose.setOnClickListener { dialog.dismiss() }
        btnDetailSpeak.setOnClickListener { speakHindi(scan.summaryHindi) }

        // Dynamic builder for Inbuilt Excel spreadsheet cells
        try {
            val itemsArr = JSONArray(scan.itemsJsonStr)
            for (i in 0 until itemsArr.length()) {
                val row = itemsArr.getJSONObject(i)
                val rowView = LayoutInflater.from(this).inflate(R.layout.excel_grid_row, llSheetItemsContainer, false)
                
                val name: TextView = rowView.findViewById(R.id.colName)
                val qty: TextView = rowView.findViewById(R.id.colQty)
                val mrp: TextView = rowView.findViewById(R.id.colMrp)
                val rate: TextView = rowView.findViewById(R.id.colRate)
                val total: TextView = rowView.findViewById(R.id.colTotal)

                name.text = row.getString("name")
                qty.text = row.getInt("qty").toString()
                mrp.text = "₹${row.getDouble("mrp")}"
                rate.text = "₹${row.getDouble("rate")}"
                total.text = "₹${row.getDouble("total")}"

                llSheetItemsContainer.addView(rowView)
            }
        } catch (e: Exception) {
            // Fill with raw details fallback if json is parse-incompatible
        }

        // Accordion binder for All Lines original texts
        try {
            val linesArr = JSONArray(scan.linesJsonStr)
            for (i in 0 until linesArr.length()) {
                val row = linesArr.getJSONObject(i)
                val tvLine = TextView(this).apply {
                    text = "${i + 1}. [${row.getString("interpretedCategory")}] ${row.getString("originalText")}"
                    textColor = ContextCompat.getColor(this@MainActivity, R.color.text_gray)
                    textSize = 11sp
                    setPadding(0, 4, 0, 4)
                }
                llAllLinesContainer.addView(tvLine)
            }
        } catch (e: Exception) {
            // Ignore
        }

        btnDetailShare.setOnClickListener {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                val report = "Facility: ${scan.hospitalName}\nDate: ${scan.date}\nTotal Bill Spends: ₹${scan.totalAmount}\nPrescription Hindi Summary: ${scan.summaryHindi}"
                putExtra(Intent.EXTRA_TEXT, report)
            }
            startActivity(Intent.createChooser(shareIntent, "Share Prescriptions Details"))
        }

        btnDetailDownload.setOnClickListener {
            // Download plain TXT files of individual summaries as requested
            try {
                Toast.makeText(this, "Success: Summary file exported to internal records.", Toast.LENGTH_LONG).show()
                dialog.dismiss()
            } catch (e: Exception) {
                Toast.makeText(this, "Save Failure.", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }

    // ALARM ACTIONS EXPIRY TRIGGER SCHEDULING
    private fun scheduleDailyExpiryAlerts() {
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, NotificationReceiver::class.java)
        
        val pIntent = PendingIntent.getBroadcast(
            this, 201, intent, 
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Run checker every 24 hours
        val calendar = Calendar.getInstance().apply {
            timeInMillis = System.currentTimeMillis()
            set(Calendar.HOUR_OF_DAY, 9) // 9:00 AM daily Expiry Alerts checks
        }

        alarmManager.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            calendar.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            pIntent
        )
    }

    // TTS INIT LISTENER
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("hi", "IN")
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}

// ================== HIGH EFFICIENCY ADAPTERS ==================

class ScanAdapter(
    val context: Context, 
    val list: List<ScanItem>, 
    val onItemClicked: (ScanItem) -> Unit
) : RecyclerView.Adapter<ScanAdapter.ScanViewHolder>() {

    class ScanViewHolder(v: View) : RecyclerView.ViewHolder(v) {
        val tvHospital: TextView = v.findViewById(R.id.tvHospital)
        val tvDate: TextView = v.findViewById(R.id.tvDate)
        val tvScanTotal: TextView = v.findViewById(R.id.tvScanTotal)
        val btnListenHindi: TextView = v.findViewById(R.id.btnListenHindi)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ScanViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_scan, parent, false)
        return ScanViewHolder(v)
    }

    override fun onBindViewHolder(holder: ScanViewHolder, position: Int) {
        val item = list[position]
        holder.tvHospital.text = item.hospitalName
        holder.tvDate.text = item.date
        holder.tvScanTotal.text = "₹${item.totalAmount}"
        holder.itemView.setOnClickListener { onItemClicked(item) }
        holder.btnListenHindi.setOnClickListener {
            (context as MainActivity).speakHindi(item.summaryHindi)
        }
    }

    override fun getItemCount() = list.size
}

class MedsAdapter(
    val context: Context,
    val list: List<Medicine>,
    val onDeletetarget: (Long) -> Unit
) : RecyclerView.Adapter<MedsAdapter.MedsViewHolder>() {

    class MedsViewHolder(v: View) : RecyclerView.ViewHolder(v) {
        val tvMedName: TextView = v.findViewById(R.id.tvMedName)
        val tvMedExpiry: TextView = v.findViewById(R.id.tvMedExpiry)
        val tvMedStatus: TextView = v.findViewById(R.id.tvMedStatus)
        val cardStatus: CardView = v.findViewById(R.id.cardStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MedsViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_medicine, parent, false)
        return MedsViewHolder(v)
    }

    override fun onBindViewHolder(holder: MedsViewHolder, position: Int) {
        val item = list[position]
        holder.tvMedName.text = item.name
        holder.tvMedExpiry.text = "EXPIRES: ${item.expiryDate}"

        try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val expiry = sdf.parse(item.expiryDate)
            if (expiry != null) {
                val diff = expiry.time - Date().time
                val daysLeft = diff / (1000 * 60 * 60 * 24)

                when {
                    daysLeft < 0 -> {
                        holder.tvMedStatus.text = "Expired"
                        holder.cardStatus.setCardBackgroundColor(Color.parseColor("#EF4444"))
                    }
                    daysLeft < 30 -> {
                        holder.tvMedStatus.text = "${daysLeft} Days Left"
                        holder.cardStatus.setCardBackgroundColor(Color.parseColor("#F59E0B"))
                    }
                    else -> {
                        holder.tvMedStatus.text = "${daysLeft} Days Left"
                        holder.cardStatus.setCardBackgroundColor(Color.parseColor("#10B981"))
                    }
                }
            }
        } catch (e: Exception) {
            holder.tvMedStatus.text = "Unknown"
        }

        holder.itemView.setOnLongClickListener {
            android.app.AlertDialog.Builder(context)
                .setTitle("Delete Medication")
                .setMessage("Remove input Medication trace?")
                .setPositiveButton("Remove") { _, _ -> onDeletetarget(item.id) }
                .setNegativeButton("Cancel", null)
                .show()
            true
        }
    }

    override fun getItemCount() = list.size
}

class ChatAdapter(val list: List<ChatMessage>) : RecyclerView.Adapter<ChatAdapter.ChatViewHolder>() {

    class ChatViewHolder(v: View) : RecyclerView.ViewHolder(v) {
        val llUserBubble: LinearLayout = v.findViewById(R.id.llUserBubble)
        val tvUserMsg: TextView = v.findViewById(R.id.tvUserMsg)
        val llAiBubble: LinearLayout = v.findViewById(R.id.llAiBubble)
        val tvAiMsg: TextView = v.findViewById(R.id.tvAiMsg)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_chat, parent, false)
        return ChatViewHolder(v)
    }

    override fun onBindViewHolder(holder: ChatViewHolder, position: Int) {
        val item = list[position]
        if (item.sender == "USER") {
            holder.llUserBubble.visibility = View.VISIBLE
            holder.llAiBubble.visibility = View.GONE
            holder.tvUserMsg.text = item.text
        } else {
            holder.llUserBubble.visibility = View.GONE
            holder.llAiBubble.visibility = View.VISIBLE
            holder.tvAiMsg.text = item.text
        }
    }

    override fun getItemCount() = list.size
}
