package com.medivault.fortress

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NotificationReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val db = DatabaseHelper(context)
        val medicines = db.getAllMedicines()
        
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val today = Date()

        var expiredCount = 0
        var nearExpiryCount = 0

        for (med in medicines) {
            try {
                val expDate = sdf.parse(med.expiryDate) ?: continue
                val diff = expDate.time - today.time
                val daysLeft = diff / (1000 * 60 * 60 * 24)

                if (daysLeft < 0) {
                    expiredCount++
                } else if (daysLeft < 30) {
                    nearExpiryCount++
                }
            } catch (e: Exception) {
                // Ignore parsing errors
            }
        }

        if (expiredCount > 0 || nearExpiryCount > 0) {
            val title = "MediVault Alert"
            val message = "You have $expiredCount expired and $nearExpiryCount near-expiry medications. Please check your cabinet."
            showPushNotification(context, title, message)
        }
    }

    private fun showPushNotification(context: Context, title: String, message: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "med_expiry_alerts"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Medicine Expiry Alerts",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)

        notificationManager.notify(101, builder.build())
    }
}
