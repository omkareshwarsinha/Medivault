package com.medivault.fortress

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "medivault_fortress.db"
        private const val DATABASE_VERSION = 1

        const val TABLE_SCANS = "scans"
        const val COL_SCAN_ID = "id"
        const val COL_SCAN_DATE = "scan_date"
        const val COL_SCAN_HOSPITAL = "hospital"
        const val COL_SCAN_TOTAL = "total"
        const val COL_SCAN_TYPE = "doc_type"
        const val COL_SCAN_SUMMARY = "summary_hindi"
        const val COL_SCAN_RAW = "raw_text"
        const val COL_SCAN_ITEMS = "items_json"
        const val COL_SCAN_LINES = "all_lines_json"

        const val TABLE_MEDS = "medicines"
        const val COL_MED_ID = "id"
        const val COL_MED_NAME = "name"
        const val COL_MED_EXPIRY = "expiry_date"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createScansTable = ("CREATE TABLE $TABLE_SCANS (" +
                "$COL_SCAN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COL_SCAN_DATE TEXT, " +
                "$COL_SCAN_HOSPITAL TEXT, " +
                "$COL_SCAN_TOTAL REAL, " +
                "$COL_SCAN_TYPE TEXT, " +
                "$COL_SCAN_SUMMARY TEXT, " +
                "$COL_SCAN_RAW TEXT, " +
                "$COL_SCAN_ITEMS TEXT, " +
                "$COL_SCAN_LINES TEXT)")
        db.execSQL(createScansTable)

        val createMedsTable = ("CREATE TABLE $TABLE_MEDS (" +
                "$COL_MED_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COL_MED_NAME TEXT, " +
                "$COL_MED_EXPIRY TEXT)")
        db.execSQL(createMedsTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_SCANS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_MEDS")
        onCreate(db)
    }

    // SCANS API
    fun insertScan(
        date: String, hospital: String, total: Double, docType: String,
        summary: String, rawText: String, itemsJsonStr: String, linesJsonStr: String
    ): Long {
        val db = this.writableDatabase
        val cv = ContentValues().apply {
            put(COL_SCAN_DATE, date)
            put(COL_SCAN_HOSPITAL, hospital)
            put(COL_SCAN_TOTAL, total)
            put(COL_SCAN_TYPE, docType)
            put(COL_SCAN_SUMMARY, summary)
            put(COL_SCAN_RAW, rawText)
            put(COL_SCAN_ITEMS, itemsJsonStr)
            put(COL_SCAN_LINES, linesJsonStr)
        }
        return db.insert(TABLE_SCANS, null, cv)
    }

    fun getAllScans(): List<ScanItem> {
        val list = ArrayList<ScanItem>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_SCANS ORDER BY $COL_SCAN_ID DESC", null)
        if (cursor.moveToFirst()) {
            do {
                val item = ScanItem(
                    id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_SCAN_ID)),
                    date = cursor.getString(cursor.getColumnIndexOrThrow(COL_SCAN_DATE)),
                    hospitalName = cursor.getString(cursor.getColumnIndexOrThrow(COL_SCAN_HOSPITAL)),
                    totalAmount = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_SCAN_TOTAL)),
                    documentType = cursor.getString(cursor.getColumnIndexOrThrow(COL_SCAN_TYPE)),
                    summaryHindi = cursor.getString(cursor.getColumnIndexOrThrow(COL_SCAN_SUMMARY)),
                    fullRawText = cursor.getString(cursor.getColumnIndexOrThrow(COL_SCAN_RAW)),
                    itemsJsonStr = cursor.getString(cursor.getColumnIndexOrThrow(COL_SCAN_ITEMS)),
                    linesJsonStr = cursor.getString(cursor.getColumnIndexOrThrow(COL_SCAN_LINES))
                )
                list.add(item)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }

    fun deleteAllScans() {
        val db = this.writableDatabase
        db.execSQL("DELETE FROM $TABLE_SCANS")
    }

    // MEDICINES API
    fun insertMedicine(name: String, expiry: String): Long {
        val db = this.writableDatabase
        val cv = ContentValues().apply {
            put(COL_MED_NAME, name)
            put(COL_MED_EXPIRY, expiry)
        }
        return db.insert(TABLE_MEDS, null, cv)
    }

    fun getAllMedicines(): List<Medicine> {
        val list = ArrayList<Medicine>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_MEDS ORDER BY $COL_MED_ID DESC", null)
        if (cursor.moveToFirst()) {
            do {
                val item = Medicine(
                    id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_MED_ID)),
                    name = cursor.getString(cursor.getColumnIndexOrThrow(COL_MED_NAME)),
                    expiryDate = cursor.getString(cursor.getColumnIndexOrThrow(COL_MED_EXPIRY))
                )
                list.add(item)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }

    fun deleteMed(id: Long) {
        val db = this.writableDatabase
        db.delete(TABLE_MEDS, "$COL_MED_ID = ?", arrayOf(id.toString()))
    }
}

data class ScanItem(
    val id: Long,
    val date: String,
    val hospitalName: String,
    val totalAmount: Double,
    val documentType: String,
    val summaryHindi: String,
    val fullRawText: String,
    val itemsJsonStr: String,
    val linesJsonStr: String
)

data class Medicine(
    val id: Long,
    val name: String,
    val expiryDate: String
)

data class ChatMessage(
    val id: Long,
    val sender: String, // "USER" or "AI"
    val text: String
)
